/* ================= Costoe app ================= */
let PRODUCTS = [];
const CATEGORIES = window.COSTOE_CATEGORIES || [];
const $ = (s, r = document) => r.querySelector(s);
const money = n => Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const byId = id => PRODUCTS.find(p => p.id === id);
const catNames = () => CATEGORIES.map(c => c.name);

/* live USD -> PKR rate (fetched at startup, sensible fallback) */
window._pkrRate = window._pkrRate || 277;
const pkr = usd => 'Rs ' + Math.round(Number(usd) * window._pkrRate).toLocaleString('en-US');
function fetchRate(){
  fetch('https://open.er-api.com/v6/latest/USD').then(r => r.json()).then(d => {
    if (d && d.rates && d.rates.PKR){ window._pkrRate = d.rates.PKR; renderRoute(); }
  }).catch(() => {});
}

/* ---------- storage ---------- */
const store = {
  cart(){ return JSON.parse(localStorage.getItem('costoe_cart') || '[]'); },
  setCart(c){ localStorage.setItem('costoe_cart', JSON.stringify(c)); renderHeader(); },
  users(){ return JSON.parse(localStorage.getItem('costoe_users') || '[]'); },
  setUsers(u){ localStorage.setItem('costoe_users', JSON.stringify(u)); },
  session(){ return JSON.parse(localStorage.getItem('costoe_session') || 'null'); },
  setSession(s){ s ? localStorage.setItem('costoe_session', JSON.stringify(s)) : localStorage.removeItem('costoe_session'); renderHeader(); },
  orders(){ return JSON.parse(localStorage.getItem('costoe_orders') || '[]'); },
  setOrders(o){ localStorage.setItem('costoe_orders', JSON.stringify(o)); },
  inbox(){ return JSON.parse(localStorage.getItem('costoe_inbox') || '[]'); },
  setInbox(m){ localStorage.setItem('costoe_inbox', JSON.stringify(m)); },
  sellers(){ return JSON.parse(localStorage.getItem('costoe_sellers') || '[]'); },
  setSellers(s){ localStorage.setItem('costoe_sellers', JSON.stringify(s)); },
  sellerSession(){ return JSON.parse(localStorage.getItem('costoe_seller_session') || 'null'); },
  setSellerSession(s){ s ? localStorage.setItem('costoe_seller_session', JSON.stringify(s)) : localStorage.removeItem('costoe_seller_session'); },
  sellerProducts(){ return JSON.parse(localStorage.getItem('costoe_seller_products') || '[]'); },
  setSellerProducts(p){
    try { localStorage.setItem('costoe_seller_products', JSON.stringify(p)); refreshProducts(); return true; }
    catch(e){ toast('Storage is full. Try fewer or smaller images.'); return false; }
  },
  sellerInbox(){ return JSON.parse(localStorage.getItem('costoe_seller_inbox') || '[]'); },
  setSellerInbox(m){ localStorage.setItem('costoe_seller_inbox', JSON.stringify(m)); },
  addresses(){ return JSON.parse(localStorage.getItem('costoe_addresses') || '[]'); },
  setAddresses(a){ localStorage.setItem('costoe_addresses', JSON.stringify(a)); },
  wishlist(){ return JSON.parse(localStorage.getItem('costoe_wishlist') || '[]'); },
  setWishlist(w){ localStorage.setItem('costoe_wishlist', JSON.stringify(w)); renderHeader(); },
  promoUsage(){ return JSON.parse(localStorage.getItem('costoe_promo') || '{}'); },
  setPromoUsage(o){ localStorage.setItem('costoe_promo', JSON.stringify(o)); }
};

/* merge base catalog (empty) with live seller listings */
function refreshProducts(){
  PRODUCTS = [...(window.COSTOE_PRODUCTS || []), ...store.sellerProducts()];
}
refreshProducts();

const ADMIN_USER = 'CostoeAdmin';
const ADMIN_PASS = 'Ab21212222';
const SUPPORT_MAIL = 'help@costoe.mails';
const ADMINS = [
  { user: 'CostoeAdmin', pass: 'Ab21212222', name: 'Costoe Admin', mail: SUPPORT_MAIL },
  { user: 'contact.abdullahhassan@gmail.com', pass: 'Ab212122', name: 'Admin Abdullah2', mail: SUPPORT_MAIL }
];
function matchAdmin(raw, pass){
  const r = (raw || '').trim().toLowerCase();
  return ADMINS.find(a => a.user.toLowerCase() === r && a.pass === pass) || null;
}
const isAdmin = () => { const s = store.session(); return !!(s && s.role === 'admin'); };
/* a seller account belongs to the signed-in buyer account (per user) */
const currentSeller = () => {
  const s = store.session();
  if (!s || s.role === 'admin') return null;
  return store.sellers().find(x => x.userEmail === s.email) || null;
};
const sellerUnread = id => store.sellerInbox().filter(m => m.sellerId === id && !m.read).length;
const unreadCount = () => store.inbox().filter(m => !m.read).length;
const cartCount = () => store.cart().reduce((a, i) => a + i.qty, 0);
const cartItems = () => store.cart().map(i => ({ ...byId(i.id), qty: i.qty })).filter(i => i.id);
const cartTotal = () => cartItems().reduce((a, i) => a + i.price * i.qty, 0);

/* stock helpers (products without a stock field are treated as unlimited) */
const stockOf = p => (p && typeof p.stock === 'number') ? p.stock : Infinity;
const inStock = p => stockOf(p) > 0;

/* per-user saved addresses + wishlist */
const myAddresses = () => { const s = store.session(); return s ? store.addresses().filter(a => a.email === s.email) : []; };
const myWishlist = () => { const s = store.session(); return s ? store.wishlist().filter(w => w.email === s.email).map(w => w.id) : []; };
const wishCount = () => myWishlist().length;
const inWishlist = id => myWishlist().includes(id);
function toggleWishlist(id, ev){
  if (ev) ev.stopPropagation();
  const s = store.session();
  if (!s){ window._afterAuth = '#/product/' + id; toast('Please sign in to save items.'); go('#/signin'); return; }
  let w = store.wishlist();
  const has = w.find(x => x.email === s.email && x.id === id);
  if (has){ w = w.filter(x => !(x.email === s.email && x.id === id)); toast('Removed from your saved items.'); }
  else { w.push({ email: s.email, id }); toast('Saved to your list.'); }
  store.setWishlist(w);
  renderRoute();
}

function addToCart(id, qty = 1){
  const p = byId(id);
  const max = stockOf(p);
  if (max <= 0){ toast('Sorry, this item is out of stock.'); return; }
  const c = store.cart();
  const ex = c.find(i => i.id === id);
  const current = ex ? ex.qty : 0;
  let next = current + qty;
  if (next > max){ next = max; toast(`Only ${max} in stock. Cart set to ${max}.`); }
  else { toast(`Added to cart (${cartCount() + qty} item${cartCount() + qty > 1 ? 's' : ''})`); }
  if (ex) ex.qty = next; else c.push({ id, qty: next });
  store.setCart(c);
}
function setQty(id, qty){
  let c = store.cart();
  const max = stockOf(byId(id));
  if (qty > max){ qty = max; toast(`Only ${max} in stock.`); }
  if (qty <= 0) c = c.filter(i => i.id !== id);
  else { const it = c.find(i => i.id === id); if (it) it.qty = qty; }
  store.setCart(c);
}

/* ---------- toast ---------- */
let toastT;
function toast(msg){
  let t = $('#toast');
  if (!t){ t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2200);
}

function starStr(r){
  const full = Math.floor(r), half = r - full >= 0.5;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(5 - full - (half ? 1 : 0));
}

/* ---------- reusable empty state ---------- */
function emptyState({ title, text, actions = [] }){
  return `
  <div class="empty-state">
    <h2>${title}</h2>
    <p>${text}</p>
    <div class="row">${actions.map(a => `<button class="${a.cls || 'btn-primary'}" style="width:auto;padding:12px 26px" onclick="${a.onclick}">${a.label}</button>`).join('')}</div>
  </div>`;
}

/* ---------- header (app style) ---------- */
function headerSellLink(){
  if (isAdmin()) return '';
  const seller = currentSeller();
  if (seller){
    const u = sellerUnread(seller.id);
    return `<span class="sell-link" onclick="go('#/seller')">Switch to seller${u ? ` <span class="sl-badge">${u}</span>` : ''}</span>`;
  }
  return `<span class="sell-link" onclick="go('#/sell')">Sell on Costoe</span>`;
}
function renderHeader(){
  const { path } = parseRoute();
  const activeCat = new URLSearchParams((location.hash.split('?')[1] || '')).get('cat');
  $('#hdr').innerHTML = `
   <div class="appbar">
     <div class="brandbar">
       <img class="brand-logo" src="assets/costoe-logo.png" alt="costoe" onclick="go('#/')"/>
       <div class="brand-right">
         <span class="loc-line" onclick="go('#/')">Deliver to <b>Pakistan</b></span>
         ${headerSellLink()}
       </div>
     </div>
     <form class="app-search" onsubmit="return doSearch(event)">
       <input id="searchInput" type="text" placeholder="Search costoe" aria-label="Search costoe"/>
       <button type="submit">Search</button>
     </form>
     <div class="app-pills">
       <span class="app-pill ${path === '/products' && !activeCat ? 'active' : ''}" onclick="go('#/products')">All</span>
       ${CATEGORIES.map(c => `<span class="app-pill ${activeCat === c.name ? 'active' : ''}" onclick="go('#/products?cat=${encodeURIComponent(c.name)}')">${c.name}</span>`).join('')}
     </div>
   </div>`;
  const inp = $('#searchInput');
  if (inp && window._lastQuery) inp.value = window._lastQuery;
  renderBottomNav();
}
function doSearch(e){
  e.preventDefault();
  const q = $('#searchInput').value.trim();
  window._lastQuery = q;
  go(`#/search?q=${encodeURIComponent(q)}`);
  return false;
}

/* ---------- bottom app nav ---------- */
function renderBottomNav(){
  const el = $('#bottomnav');
  if (!el) return;
  const s = store.session();
  const { path } = parseRoute();
  const on = p => path === p ? 'active' : '';
  const adminTab = isAdmin()
    ? `<a class="${on('/inbox')}" onclick="go('#/inbox')">Inbox${unreadCount() ? ` <span class="cbadge">${unreadCount()}</span>` : ''}</a>`
    : '';
  el.innerHTML = `
    <a class="${on('/')}" onclick="go('#/')">Home</a>
    <a class="${on('/products')}" onclick="go('#/products')">Shop</a>
    <a class="${on('/cart')}" onclick="go('#/cart')">Cart${cartCount() ? ` <span class="cbadge">${cartCount()}</span>` : ''}</a>
    ${adminTab || `<a class="${on('/orders')}" onclick="go('#/orders')">Orders</a>`}
    <a class="${on('/account') || on('/signin')}" onclick="go('${s ? '#/account' : '#/signin'}')">${s ? (isAdmin() ? 'Admin' : 'Account') : 'Sign in'}</a>`;
}

/* ---------- footer ---------- */
function footerHTML(){
  return `
  <div class="foot">
    <div class="foot-top" onclick="window.scrollTo({top:0,behavior:'smooth'})">Back to top ↑</div>
    <div class="foot-cols">
      <div>
        <img class="logo-img" src="assets/costoe-logo-white.png" alt="costoe" style="height:26px"/>
        <p class="about">Costoe is an online store in Pakistan. We deliver electronics, books, gadgets, car and bike accessories and more, with cash on delivery and Bykea shipping.</p>
      </div>
      <div><h4>Shop</h4>${CATEGORIES.map(c => `<a onclick="go('#/products?cat=${encodeURIComponent(c.name)}')">${c.name}</a>`).join('')}</div>
      <div><h4>Company</h4><a onclick="go('#/about')">About us</a><a onclick="go('#/contact')">Contact</a><a onclick="go('#/sell')">Sell on Costoe</a><a onclick="go('#/seller')">Seller dashboard</a></div>
      <div><h4>Help</h4><a onclick="go('#/account')">Your account</a><a onclick="go('#/orders')">Your orders</a><a onclick="go('#/cart')">Your cart</a><a onclick="go('#/inbox')">Staff inbox</a></div>
    </div>
    <div class="foot-bottom">Terms · Privacy · © 2026 Costoe</div>
  </div>`;
}

/* ---------- product card ---------- */
function cardHTML(p){
  const off = p.listPrice > p.price ? Math.round((1 - p.price / p.listPrice) * 100) : 0;
  const [w, f] = money(p.price).split('.');
  const st = stockOf(p);
  const saved = inWishlist(p.id);
  return `
  <div class="card" onclick="go('#/product/${p.id}')">
    <div class="imgbox"><img src="${p.img}" alt="${p.title}" loading="lazy">
      ${st <= 0 ? `<span class="soldout">Out of stock</span>` : ''}
      <button class="save-dot ${saved ? 'on' : ''}" title="${saved ? 'Saved' : 'Save for later'}" onclick="toggleWishlist('${p.id}', event)">${saved ? 'Saved' : 'Save'}</button>
    </div>
    ${off ? `<span class="badge">${off}% off</span>` : ''}
    <div class="ttl">${p.title}</div>
    ${p.sellerName ? `<div class="by-seller">by ${p.sellerName}</div>` : ''}
    <div class="price"><span class="cur">$</span><span class="whole">${w}</span><span class="frac">${f}</span>
      ${off ? `<span class="list"><s>$${money(p.listPrice)}</s></span>` : ''}
    </div>
    <div class="pkr">${pkr(p.price)}</div>
    ${st !== Infinity && st > 0 && st <= 5 ? `<div class="deal" style="color:var(--danger)">Only ${st} left</div>` : ''}
  </div>`;
}

/* ================= VIEWS ================= */
function viewHome(){
  return `
  <div class="app-wrap">

    <div class="promo-ticker" onclick="go('#/signin')">
      <div class="promo-track">
        ${Array(3).fill('<span class="promo-item">🎉 Sign up and get <b>10% off</b>, up to <b>Rs 1,000</b>, on your first <b>2 orders</b> — applied automatically at checkout.</span>').join('')}
      </div>
    </div>

    <div class="banners">
      <div class="banner">
        <img src="assets/banners/banner-main.png" alt="">
        <div class="ov">
          <span class="kick">Free delivery</span>
          <h3>Free delivery on your order</h3>
          <p>We ship across Pakistan, with cash on delivery available.</p>
          <button onclick="go('#/products')">Start shopping</button>
        </div>
      </div>
      <div class="banner">
        <img src="assets/banners/banner-deals.png" alt="">
        <div class="ov">
          <span class="kick">Everyday prices</span>
          <h3>Good prices, every day</h3>
          <p>Electronics, books, gadgets, auto care and more.</p>
          <button onclick="go('#/products')">See catalogues</button>
        </div>
      </div>
    </div>
    <div class="banner-dots"><i class="on"></i><i></i></div>

    <div class="app-trust">
      <div class="t"><h4>Bykea delivery</h4><p>Across Pakistan</p></div>
      <div class="t"><h4>Cash on Delivery</h4><p>Pay when your order arrives</p></div>
      <div class="t"><h4>Costoe Pays</h4><p>Coming soon</p></div>
      <div class="t"><h4>Returns</h4><p>30 days to return an item</p></div>
    </div>

    <div class="feed">
      ${CATEGORIES.slice(0, 4).map(c => `
      <div class="promo-card" onclick="go('#/products?cat=${encodeURIComponent(c.name)}')">
        <h4>${c.name}</h4><div class="ph"><img src="${c.img}" alt=""></div>
        <span class="cta">Browse ${c.name}</span>
      </div>`).join('')}
    </div>

    <div class="sec-title">Shop by catalogue</div>
    <div class="app-cats">
      ${CATEGORIES.map(c => `<div class="app-cat" onclick="go('#/products?cat=${encodeURIComponent(c.name)}')">
        <div class="ph"><img src="${c.img}" alt=""></div><span class="nm">${c.name}</span></div>`).join('')}
    </div>

    ${PRODUCTS.length ? `
    <div class="sec-title">New on Costoe</div>
    <div class="feed">
      ${PRODUCTS.slice().reverse().slice(0, 10).map(p => `
      <div class="promo-card" onclick="go('#/product/${p.id}')">
        <div class="ph"><img src="${p.img}" alt=""></div>
        <h4 style="font-size:14px;font-weight:600;padding:10px 12px 2px">${p.title}</h4>
        <span class="cta">$${money(p.price)} · ${pkr(p.price)}</span>
      </div>`).join('')}
    </div>` : `
    <div class="sec-title">Sell on Costoe</div>
    <div style="padding:0 16px 6px">
      <div class="sell-cta">
        <div>
          <h3>Start selling on Costoe</h3>
          <p>Open a seller account, list your products and reach buyers across Pakistan.</p>
        </div>
        <button class="btn-primary" style="width:auto;padding:12px 24px" onclick="go('#/sell')">Become a seller</button>
      </div>
    </div>`}

  </div>`;
}

function viewProducts(params){
  const cat = params.get('cat');
  const deals = params.get('deals');
  let list = PRODUCTS.slice();
  if (cat) list = list.filter(p => p.category === cat);
  if (deals) list = list.filter(p => p.listPrice > p.price);
  const chips = ['All', ...catNames()];
  const heading = cat || (deals ? 'Deals' : 'All products');
  return `
  <div class="bc"><a onclick="go('#/')">Home</a> › ${heading}</div>
  <div class="results-head"><b>${list.length}</b> ${list.length === 1 ? 'product' : 'products'} ${cat ? 'in ' + cat : ''}</div>
  <div class="filters">
    ${chips.map(c => `<span class="chip ${(c==='All'&&!cat)||c===cat?'active':''}" onclick="go('${c==='All'?'#/products':'#/products?cat='+encodeURIComponent(c)}')">${c}</span>`).join('')}
    <span class="chip ${deals?'active':''}" onclick="go('#/products?deals=1')">Deals</span>
  </div>
  <div class="section" style="margin-top:8px">
    ${list.length
      ? `<div class="grid">${list.map(cardHTML).join('')}</div>`
      : emptyState({
          title: `No products in ${heading} yet`,
          text: 'There are no products in this catalogue yet. Please check back soon.',
          actions: [
            { label: 'Notify me', onclick: "go('#/signup')" },
            { label: 'Back to home', cls: 'btn-ghost', onclick: "go('#/')" }
          ]
        })}
  </div>`;
}

function viewSearch(params){
  const q = (params.get('q') || '').toLowerCase();
  const cat = params.get('cat');
  window._lastQuery = params.get('q') || '';
  let list = PRODUCTS.filter(p => (p.title + ' ' + (p.brand || '') + ' ' + (p.sellerName || '') + ' ' + p.category + ' ' + (p.bullets || []).join(' ')).toLowerCase().includes(q));
  if (cat) list = list.filter(p => p.category === cat);
  return `
  <div class="results-head">${list.length ? `<b>${list.length}</b> results for` : 'Results for'} <b>"${params.get('q') || ''}"</b>${cat ? ' in ' + cat : ''}</div>
  <div class="section" style="margin-top:8px">
    ${list.length
      ? `<div class="grid">${list.map(cardHTML).join('')}</div>`
      : emptyState({
          title: 'Nothing to show yet',
          text: 'Nothing matches your search yet. Please check back soon.',
          actions: [
            { label: 'Notify me', onclick: "go('#/signup')" },
            { label: 'Back to home', cls: 'btn-ghost', onclick: "go('#/')" }
          ]
        })}
  </div>`;
}

function viewProduct(id){
  const p = byId(id);
  if (!p) return emptyState({ title: 'Product not found', text: 'This item is not available right now.', actions: [{ label: 'Go home', onclick: "go('#/')" }] });
  const off = p.listPrice > p.price ? Math.round((1 - p.price / p.listPrice) * 100) : 0;
  const [w, f] = money(p.price).split('.');
  const imgs = (p.images && p.images.length) ? p.images : [p.img];
  const related = PRODUCTS.filter(x => x.category === p.category && x.id !== p.id).slice(0, 5);
  const variantSel = (p.variants || []).filter(v => v.options && v.options.length).map((v, i) =>
    `<div class="field" style="margin-bottom:10px"><label>${v.name}</label><select id="pv-${i}">${v.options.map(o => `<option>${o}</option>`).join('')}</select></div>`).join('');
  const desc = p.descHTML ? `<div class="pd-desc">${p.descHTML}</div>` : (p.bullets ? `<ul>${p.bullets.map(b => `<li>${b}</li>`).join('')}</ul>` : '');
  const st = stockOf(p);
  const hasStock = st > 0;
  const stockLine = st === Infinity ? `<div class="instock">In stock</div>`
    : (st <= 0 ? `<div class="outstock">Out of stock</div>`
      : (st <= 5 ? `<div class="lowstock">Only ${st} left in stock</div>`
        : `<div class="instock">In stock (${st.toLocaleString()} available)</div>`));
  const qtyMax = st === Infinity ? 10 : Math.min(st, 10);
  const saved = inWishlist(p.id);
  return `
  <div class="bc"><a onclick="go('#/')">Home</a> › <a onclick="go('#/products?cat=${encodeURIComponent(p.category)}')">${p.category}</a></div>
  <div class="pd">
    <div class="pd-gallery">
      <div class="main"><img id="pd-main-img" src="${imgs[0]}" alt="${p.title}"></div>
      ${imgs.length > 1 ? `<div class="thumbs">${imgs.map((im, i) => `<div class="thumb ${i === 0 ? 'on' : ''}" onclick="pdSwap(this,'${i}')"><img src="${im}" data-full="${im}" alt=""></div>`).join('')}</div>` : ''}
    </div>
    <div class="pd-info">
      <h1>${p.title}</h1>
      ${p.sellerName ? `<div class="by">Sold by <b>${p.sellerName}</b></div>` : ''}
      <div class="pd-price">${off ? `<span style="color:var(--danger);font-size:22px;font-weight:800">${off}% off</span> ` : ''}<span class="cur">$</span><span class="whole">${w}</span><span class="frac">${f}</span>${off ? `<span style="font-size:14px;color:var(--muted);margin-left:8px"><s>$${money(p.listPrice)}</s></span>` : ''}</div>
      <div class="pd-pkr">${pkr(p.price)}</div>
      <h3>About this item</h3>${desc}
    </div>
    <div class="buybox">
      <div class="pd-price"><span class="cur">$</span><span class="whole">${w}</span><span class="frac">${f}</span></div>
      <div class="pd-pkr" style="margin-bottom:8px">${pkr(p.price)}</div>
      <div class="free">Delivery by Bykea across <b>Pakistan</b>.</div>
      ${stockLine}
      ${hasStock ? `
      ${variantSel}
      <select id="pdQty">${Array.from({length: qtyMax}, (_, k) => k + 1).map(n => `<option value="${n}">Quantity: ${n}</option>`).join('')}</select>
      <button class="btn btn-cart" onclick="addToCart('${p.id}', +document.getElementById('pdQty').value)">Add to cart</button>
      <button class="btn btn-buy" onclick="buyNow('${p.id}', +document.getElementById('pdQty').value)">Buy now</button>
      ` : `<button class="btn btn-outline" disabled style="opacity:.6;cursor:not-allowed">Out of stock</button>`}
      <button class="btn btn-save ${saved ? 'on' : ''}" onclick="toggleWishlist('${p.id}')">${saved ? 'Saved to your list' : 'Save for later'}</button>
      <div class="meta">
        <div><span class="k">Payment</span> Cash on Delivery (Costoe Pays coming soon)</div>
        <div><span class="k">Delivery</span> Bykea</div>
        <div><span class="k">Returns</span> 30 days</div>
      </div>
    </div>
  </div>
  ${related.length ? `<div class="section"><div class="section-head"><h2>More in ${p.category}</h2></div><div class="grid">${related.map(cardHTML).join('')}</div></div>` : ''}`;
}
function pdSwap(el, i){
  document.querySelectorAll('.pd-gallery .thumb').forEach(t => t.classList.remove('on'));
  el.classList.add('on');
  const full = el.querySelector('img').getAttribute('data-full');
  const main = document.getElementById('pd-main-img');
  if (main) main.src = full;
}

function viewCart(){
  const items = cartItems();
  if (!items.length) return `<div class="container" style="margin-top:24px">${emptyState({
    title: 'Your Costoe cart is empty',
    text: 'Items you add to your cart will show up here.',
    actions: [{ label: 'Start shopping', onclick: "go('#/products')" }]
  })}</div>`;
  return `
  <div class="cart-wrap">
    <div class="cart-main">
      <h1>Your Cart</h1>
      ${items.map(p => {
        const [w, f] = money(p.price).split('.');
        return `<div class="cart-item">
          <div class="ci-img" onclick="go('#/product/${p.id}')"><img src="${p.img}" alt="${p.title}"></div>
          <div>
            <h3 onclick="go('#/product/${p.id}')">${p.title}</h3>
            ${stockOf(p) === Infinity ? `<div class="instock">In stock</div>` : (stockOf(p) <= 5 ? `<div class="lowstock">Only ${stockOf(p)} left</div>` : `<div class="instock">In stock</div>`)}
            <div style="font-size:13px;color:var(--muted);margin-top:4px">${p.sellerName ? 'Sold by ' + p.sellerName : 'Ships from Costoe'} · Bykea delivery</div>
            <div class="qtybar">
              <div class="qtysel">
                <button onclick="setQty('${p.id}', ${p.qty - 1});renderRoute()">${p.qty === 1 ? 'x' : '-'}</button>
                <span>${p.qty}</span>
                <button onclick="setQty('${p.id}', ${p.qty + 1});renderRoute()">+</button>
              </div>
              <span class="rm" onclick="setQty('${p.id}',0);renderRoute()">Remove</span>
            </div>
          </div>
          <div class="ci-price"><span class="cur">$</span><span class="whole">${w}</span><span class="frac">.${f}</span><div class="pkr" style="text-align:right">${pkr(p.price * p.qty)}</div></div>
        </div>`;
      }).join('')}
      <div class="cart-sub">Subtotal (${cartCount()} items): <b>$${money(cartTotal())}</b></div>
    </div>
    <div class="cart-side">
      <div class="sub">Subtotal (${cartCount()} items): <b>$${money(cartTotal())}</b><div style="font-size:13px;color:var(--muted);font-weight:400">${pkr(cartTotal())}</div></div>
      <button class="btn btn-buy" onclick="proceedCheckout()">Go to checkout</button>
      <button class="btn btn-outline" onclick="go('#/products')">Continue shopping</button>
    </div>
  </div>`;
}

/* ---------- auth ---------- */
function viewSignin(){
  return `
  <div class="auth-wrap">
    <div class="auth-logo"><img class="logo-img" src="assets/costoe-logo.png" alt="costoe"/></div>
    <div class="auth-box">
      <h1>Sign in</h1>
      <form onsubmit="return doSignin(event)">
        <div class="field" id="f-email"><label>Email or mobile number</label><input type="text" id="si-email" autocomplete="username"/><div class="err">Enter your email or mobile number.</div></div>
        <div class="field" id="f-pass"><label>Password</label><input type="password" id="si-pass" autocomplete="current-password"/><div class="err">Incorrect email or password.</div></div>
        <button class="btn-primary" type="submit">Sign in</button>
      </form>
      <p class="form-note">By continuing you agree to the Costoe terms and privacy notice.</p>
    </div>
    <div class="auth-sep"><span>New to Costoe?</span></div>
    <button class="btn-ghost" onclick="go('#/signup')">Create account</button>
  </div>`;
}
function doSignin(e){
  e.preventDefault();
  const raw = $('#si-email').value.trim();
  const email = raw.toLowerCase();
  const pass = $('#si-pass').value;
  $('#f-email').classList.toggle('invalid', !raw);
  if (!raw) return false;
  // Admin login
  const adm = matchAdmin(raw, pass);
  if (adm){
    store.setSession({ name: adm.name, email: adm.user, role: 'admin', mail: adm.mail });
    toast('Signed in as admin.');
    go('#/inbox'); window._afterAuth = null;
    return false;
  }
  const u = store.users().find(u => u.email === email && u.pass === pass);
  if (!u){ $('#f-pass').classList.add('invalid'); return false; }
  store.setSession({ name: u.name, email: u.email });
  toast(`Welcome back, ${u.name.split(' ')[0]}.`);
  go(window._afterAuth || '#/'); window._afterAuth = null;
  return false;
}

function viewSignup(){
  return `
  <div class="auth-wrap">
    <div class="auth-logo"><img class="logo-img" src="assets/costoe-logo.png" alt="costoe"/></div>
    <div class="auth-box">
      <h1>Create account</h1>
      <form onsubmit="return doSignup(event)">
        <div class="field" id="s-name"><label>Your name</label><input type="text" id="su-name" placeholder="First and last name"/><div class="err">Enter your name.</div></div>
        <div class="field" id="s-email"><label>Email</label><input type="email" id="su-email" placeholder="you@example.com"/><div class="err">Enter a valid email address.</div></div>
        <div class="field" id="s-phone"><label>Mobile number</label>
          <div class="phone-row"><input class="cc" value="+92" readonly><input type="tel" id="su-phone" placeholder="3XX XXXXXXX"/></div>
          <div class="hint">Pakistan mobile number (e.g. +92 3XX XXXXXXX)</div>
          <div class="err">Enter a valid Pakistan mobile number.</div>
        </div>
        <div class="field" id="s-pass"><label>Password</label><input type="password" id="su-pass" placeholder="At least 6 characters"/><div class="err">Password must be at least 6 characters.</div></div>
        <button class="btn-primary" type="submit">Create account</button>
      </form>
      <p class="form-note">By creating an account you agree to the Costoe terms and privacy notice.</p>
      <div class="auth-sep"><span>Already have an account?</span></div>
      <button class="btn-ghost" onclick="go('#/signin')">Sign in</button>
    </div>
  </div>`;
}
function doSignup(e){
  e.preventDefault();
  const name = $('#su-name').value.trim();
  const email = $('#su-email').value.trim().toLowerCase();
  const phone = $('#su-phone').value.trim();
  const pass = $('#su-pass').value;
  let ok = true;
  const set = (id, bad) => { $(id).classList.toggle('invalid', bad); if (bad) ok = false; };
  const digits = phone.replace(/\D/g, '').replace(/^0/, '');
  set('#s-name', !name);
  set('#s-email', !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email));
  set('#s-phone', !/^3\d{9}$/.test(digits));
  set('#s-pass', pass.length < 6);
  if (!ok) return false;
  const users = store.users();
  if (users.find(u => u.email === email)){ $('#s-email').classList.add('invalid'); toast('An account with this email already exists.'); return false; }
  users.push({ name, email, phone: '+92' + digits, pass });
  store.setUsers(users);
  store.setSession({ name, email });
  toast(`Account created. Welcome, ${name.split(' ')[0]}.`);
  go(window._afterAuth || '#/'); window._afterAuth = null;
  return false;
}

function viewAccount(){
  const s = store.session();
  if (!s) { go('#/signin'); return ''; }
  if (isAdmin()){
    return `
    <div class="section" style="max-width:900px">
      <div class="section-head"><h2>Admin</h2></div>
      <p style="font-size:15px">Signed in as <b>${s.name || 'Costoe Admin'}</b> (${s.email})${s.mail ? ` &middot; mailbox <b>${s.mail}</b>` : ''}</p>
      <div class="grid" style="grid-template-columns:1fr 1fr;margin-top:14px">
        <div class="card" style="cursor:default"><h3 style="margin:0 0 6px">Order inbox</h3><p style="font-size:13px">${store.inbox().length} order(s), ${unreadCount()} unread. <a onclick="go('#/inbox')">Open inbox</a></p></div>
        <div class="card" style="cursor:default"><h3 style="margin:0 0 6px">Sign out</h3><p style="font-size:13px"><a onclick="signOut()">Sign out</a></p></div>
      </div>
    </div>`;
  }
  const orders = store.orders().filter(o => o.email === s.email);
  const seller = currentSeller();
  const acard = (title, sub, onclick) =>
    `<div class="acard" onclick="${onclick}"><h3>${title}</h3><p>${sub}</p><span class="acard-go">Open</span></div>`;
  const sellerCard = seller
    ? acard('Seller account', `Store: <b>${seller.sellerName}</b><br>${seller.mail}`, "go('#/seller')")
    : acard('Sell on Costoe', 'Open your own seller account and list products.', "go('#/sell')");
  return `
  <div class="section" style="max-width:900px">
    <div class="section-head"><h2>Your account</h2></div>
    <p style="font-size:15px">Signed in as <b>${s.name}</b> (${s.email})</p>
    <div class="acard-grid">
      ${acard('Your orders', `${orders.length} order(s). Track what you have bought.`, "go('#/orders')")}
      ${acard('Your cart', `${cartCount()} item(s) waiting for checkout.`, "go('#/cart')")}
      ${acard('Saved items', `${wishCount()} item(s) in your wishlist.`, "go('#/wishlist')")}
      ${acard('Addresses', `${myAddresses().length} saved address(es) for faster checkout.`, "go('#/addresses')")}
      ${acard('Login &amp; security', 'Update your name and mobile number.', "go('#/profile')")}
      ${sellerCard}
    </div>
    <div style="margin-top:16px"><button class="btn-ghost" style="width:auto;padding:11px 22px" onclick="signOut()">Sign out</button></div>
  </div>`;
}
function signOut(){ store.setSession(null); toast('Signed out.'); go('#/'); }
function adminReply(mid){
  const el = document.getElementById('rp-body');
  const body = (el ? el.value : '').trim();
  if (!body){ toast('Write a reply first.'); return; }
  const m = store.inbox().find(x => x.mid === mid);
  if (!m || !m.fromSellerId){ toast('Cannot reply to this message.'); return; }
  const now = new Date();
  const sinbox = store.sellerInbox();
  sinbox.push({
    mid: 'sm' + Date.now(),
    sellerId: m.fromSellerId,
    read: false,
    kind: 'mail',
    date: now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
    time: now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    from: 'Costoe Support',
    fromMail: SUPPORT_MAIL,
    subject: 'Re: ' + (m.subject || '(no subject)'),
    body
  });
  store.setSellerInbox(sinbox);
  toast('Reply sent to ' + m.from + '.');
  go('#/inbox');
}

/* ---------- edit profile ---------- */
function viewProfile(){
  const s = store.session();
  if (!s) { window._afterAuth = '#/profile'; go('#/signin'); return ''; }
  if (isAdmin()) return emptyState({ title: 'Not available', text: 'Profile editing is for buyer accounts.', actions: [{ label: 'Go to admin', onclick: "go('#/account')" }] });
  const u = store.users().find(x => x.email === s.email) || { name: s.name, phone: '' };
  const digits = (u.phone || '').replace(/\D/g, '').replace(/^92/, '');
  return `
  <div class="section" style="max-width:560px">
    <div class="section-head"><h2>Login &amp; security</h2></div>
    <div class="co-card" style="margin:0">
      <div class="field" id="pf-name"><label>Your name</label><input id="pr-name" value="${(u.name || '').replace(/"/g, '&quot;')}"/><div class="err">Enter your name.</div></div>
      <div class="field"><label>Email</label><input value="${s.email}" readonly/><div class="hint">Your email is your sign-in and cannot be changed here.</div></div>
      <div class="field" id="pf-phone"><label>Mobile number</label>
        <div class="phone-row"><input class="cc" value="+92" readonly><input id="pr-phone" type="tel" value="${digits}" placeholder="3XX XXXXXXX"/></div>
        <div class="err">Enter a valid Pakistan mobile number.</div>
      </div>
      <button class="btn-primary" style="max-width:220px" onclick="saveProfile()">Save changes</button>
    </div>
  </div>`;
}
function saveProfile(){
  const s = store.session();
  const name = ($('#pr-name').value || '').trim();
  const digits = ($('#pr-phone').value || '').replace(/\D/g, '').replace(/^0/, '');
  let ok = true;
  $('#pf-name').classList.toggle('invalid', !name); if (!name) ok = false;
  $('#pf-phone').classList.toggle('invalid', !/^3\d{9}$/.test(digits)); if (!/^3\d{9}$/.test(digits)) ok = false;
  if (!ok) return;
  const users = store.users();
  const u = users.find(x => x.email === s.email);
  if (u){ u.name = name; u.phone = '+92' + digits; store.setUsers(users); }
  store.setSession({ ...s, name });
  toast('Profile updated.');
  go('#/account');
}

/* ---------- saved items (wishlist) ---------- */
function viewWishlist(){
  const s = store.session();
  if (!s) { window._afterAuth = '#/wishlist'; go('#/signin'); return ''; }
  const items = myWishlist().map(byId).filter(Boolean);
  if (!items.length) return `<div class="container" style="margin-top:24px">${emptyState({ title: 'No saved items yet', text: 'Tap Save on any product to keep it here for later.', actions: [{ label: 'Browse products', onclick: "go('#/products')" }] })}</div>`;
  return `<div class="section"><div class="section-head"><h2>Saved items</h2></div>
    <div class="grid">${items.map(cardHTML).join('')}</div></div>`;
}

/* ---------- saved addresses ---------- */
function viewAddresses(){
  const s = store.session();
  if (!s) { window._afterAuth = '#/addresses'; go('#/signin'); return ''; }
  const list = myAddresses();
  const rows = list.length ? list.map(a => `
    <div class="addr-card">
      <div><b>${esc(a.name)}</b> · ${esc(a.phone)}<br>
        ${esc(a.a1)}${a.a2 ? ', ' + esc(a.a2) : ''}, ${esc(a.city)}, ${esc(a.state)}, ${esc(a.post)}, Pakistan
        ${a.land ? `<br><span style="color:var(--muted)">Landmark: ${esc(a.land)}</span>` : ''}
      </div>
      <button class="btn-ghost" style="width:auto;padding:8px 14px;font-size:13px;color:var(--danger);border-color:#f0caca" onclick="deleteAddress('${a.id}')">Delete</button>
    </div>`).join('') : `<p style="color:var(--muted)">You have no saved addresses yet.</p>`;
  return `
  <div class="section" style="max-width:720px">
    <div class="section-head"><h2>Your addresses</h2></div>
    <div class="addr-list">${rows}</div>
    <div class="co-card" style="margin-top:16px">
      <h3 style="margin:0 0 10px">Add a new address</h3>
      <div class="co-grid2">
        <div class="field" id="af-name"><label>Full name</label><input id="ad-name" value="${(s.name || '').replace(/"/g,'&quot;')}"/><div class="err">Enter a name.</div></div>
        <div class="field" id="af-phone"><label>Mobile number</label><div class="phone-row"><input class="cc" value="+92" readonly><input id="ad-phone" type="tel" placeholder="3XX XXXXXXX"/></div><div class="err">Enter a valid number.</div></div>
      </div>
      <div class="field" id="af-a1"><label>Address line 1</label><input id="ad-a1" placeholder="House / street"/><div class="err">Enter the address.</div></div>
      <div class="field"><label>Address line 2 (optional)</label><input id="ad-a2" placeholder="Area / town"/></div>
      <div class="co-grid2">
        <div class="field" id="af-city"><label>City</label><select id="ad-city">${PK_CITIES.map(c => `<option>${c}</option>`).join('')}</select><div class="err">Choose a city.</div></div>
        <div class="field" id="af-state"><label>Province</label><select id="ad-state">${PK_STATES.map(c => `<option>${c}</option>`).join('')}</select><div class="err">Choose a province.</div></div>
      </div>
      <div class="co-grid2">
        <div class="field" id="af-post"><label>Postal code</label><input id="ad-post" inputmode="numeric" placeholder="5 digits"/><div class="err">Enter a 5-digit code.</div></div>
        <div class="field"><label>Landmark (optional)</label><input id="ad-land" placeholder="Nearby landmark"/></div>
      </div>
      <button class="btn-primary" style="max-width:220px" onclick="saveAddress()">Save address</button>
    </div>
  </div>`;
}
function saveAddress(){
  const s = store.session();
  const v = id => ($('#' + id) ? $('#' + id).value.trim() : '');
  let ok = true;
  const set = (id, bad) => { const el = $('#' + id); if (el){ el.classList.toggle('invalid', bad); if (bad) ok = false; } };
  const digits = v('ad-phone').replace(/\D/g, '').replace(/^0/, '');
  set('af-name', !v('ad-name'));
  set('af-phone', !/^3\d{9}$/.test(digits));
  set('af-a1', !v('ad-a1'));
  set('af-city', !v('ad-city'));
  set('af-state', !v('ad-state'));
  set('af-post', !/^\d{5}$/.test(v('ad-post')));
  if (!ok){ toast('Please complete the highlighted fields.'); return; }
  const list = store.addresses();
  list.push({ id: 'a' + Date.now(), email: s.email, name: v('ad-name'), phone: '+92' + digits, a1: v('ad-a1'), a2: v('ad-a2'), city: v('ad-city'), state: v('ad-state'), post: v('ad-post'), land: v('ad-land') });
  store.setAddresses(list);
  toast('Address saved.');
  go('#/addresses');
}
function deleteAddress(id){
  store.setAddresses(store.addresses().filter(a => a.id !== id));
  toast('Address removed.');
  renderRoute();
}

function viewOrders(){
  const s = store.session();
  if (!s) { window._afterAuth = '#/orders'; go('#/signin'); return ''; }
  const orders = store.orders().filter(o => o.email === s.email).reverse();
  if (!orders.length) return `<div class="container" style="margin-top:24px">${emptyState({ title: 'No orders yet', text: 'When you place an order it will appear here.', actions: [{ label: 'Start shopping', onclick: "go('#/products')" }] })}</div>`;
  return `<div class="section" style="max-width:900px"><div class="section-head"><h2>Your Orders</h2></div>
    ${orders.map(o => `<div class="order-box"><b>Order #${o.id}</b> · ${o.date} · Total <b>$${money(o.total)}</b><br>
      Ship to: ${o.ship.name}, ${o.ship.city}, ${o.ship.state}, Pakistan<br>
      Items: ${o.items.map(i => `${i.title} ×${i.qty}`).join(' · ')}</div>`).join('')}
  </div>`;
}

/* ---------- checkout ---------- */
const PK_STATES = ['Punjab','Sindh','Khyber Pakhtunkhwa (KPK)','Balochistan','Gilgit-Baltistan','Azad Jammu & Kashmir','Islamabad Capital Territory'];
const PK_CITIES = ['Lahore','Islamabad','Rawalpindi','Karachi','Faisalabad','Multan','Hyderabad','Peshawar','Quetta','Gujranwala','Sialkot','Bahawalpur','Sargodha','Sukkur','Abbottabad','Mardan','Mingora','Larkana','Sheikhupura','Rahim Yar Khan','Gujrat','Sahiwal','Okara','Wah Cantt','Dera Ghazi Khan','Mirpur (AJK)','Muzaffarabad','Gilgit','Skardu','Other'];

const DELIVERY = {
  bykea: { label: 'Bykea', fee: 2.50, eta: '2 to 4 working days' }
};

/* sign-up promo: 10% off, capped at Rs 1000, usable twice per user */
const PROMO_MAX_PKR = 1000;
const PROMO_USES = 2;
function promoUsesLeft(){
  const s = store.session();
  if (!s || s.role === 'admin') return 0;
  const used = store.promoUsage()[s.email] || 0;
  return Math.max(0, PROMO_USES - used);
}
function promoDiscount(subUSD){
  if (promoUsesLeft() <= 0) return 0;
  const capUSD = PROMO_MAX_PKR / window._pkrRate;
  return +(Math.min(subUSD * 0.10, capUSD)).toFixed(2);
}

function proceedCheckout(){
  if (!cartItems().length) { toast('Your cart is empty.'); return; }
  if (!store.session()) { window._afterAuth = '#/checkout'; toast('Please sign in to checkout.'); go('#/signin'); return; }
  go('#/checkout');
}
function buyNow(id, qty){ addToCart(id, qty); proceedCheckout(); }

function viewCheckout(){
  const items = cartItems();
  if (!items.length) return `<div class="container" style="margin-top:24px">${emptyState({ title: 'Your cart is empty', text: 'Add something to your cart to place an order.', actions: [{ label: 'Shop now', onclick: "go('#/products')" }] })}</div>`;
  if (!store.session()) { window._afterAuth = '#/checkout'; go('#/signin'); return ''; }
  const s = store.session();
  const sub = cartTotal();
  const ship = DELIVERY.bykea.fee;
  const tax = +(sub * 0.05).toFixed(2);
  const disc = promoDiscount(sub);
  const total = +(sub + ship + tax - disc).toFixed(2);
  return `
  <div class="co-head"><img class="logo-img" src="assets/costoe-logo.png" alt="costoe" style="height:24px;display:inline-block;vertical-align:middle"/> <span style="color:var(--muted);font-size:16px">Checkout</span></div>
  <div class="co-wrap">
    <form id="coForm" onsubmit="return placeOrder(event)">
      <div class="co-card">
        <h2><span class="step">1</span> Contact details</h2>
        <div class="co-grid2">
          <div class="field" id="c-name"><label>Full name</label><input id="co-name" value="${s.name}"/><div class="err">Enter your full name.</div></div>
          <div class="field" id="c-email"><label>Email</label><input type="email" id="co-email" value="${s.email}"/><div class="err">Enter a valid email.</div></div>
        </div>
        <div class="field" id="c-phone"><label>Pakistan mobile number</label>
          <div class="phone-row"><input class="cc" value="+92" readonly><input type="tel" id="co-phone" placeholder="3XX XXXXXXX"/></div>
          <div class="err">Enter a valid Pakistan mobile number (+92 3XX XXXXXXX).</div>
        </div>
      </div>

      <div class="co-card">
        <h2><span class="step">2</span> Billing &amp; shipping address</h2>
        ${myAddresses().length ? `<div class="field"><label>Use a saved address</label>
          <select id="co-saved" onchange="fillSavedAddress()">
            <option value="">Enter a new address</option>
            ${myAddresses().map(a => `<option value="${a.id}">${esc(a.name)} — ${esc(a.a1)}, ${esc(a.city)}</option>`).join('')}
          </select><div class="hint">Manage saved addresses in your account.</div></div>` : ''}
        <div class="field" id="c-a1"><label>Address line 1</label><input id="co-a1" placeholder="House / flat no., street"/><div class="err">Enter address line 1.</div></div>
        <div class="field"><label>Address line 2 <span style="font-weight:400;color:var(--muted)">(optional)</span></label><input id="co-a2" placeholder="Area, sector, block"/></div>
        <div class="co-grid2">
          <div class="field" id="c-state"><label>State / Province</label><select id="co-state"><option value="">Select province</option>${PK_STATES.map(x => `<option>${x}</option>`).join('')}</select><div class="err">Select your province.</div></div>
          <div class="field" id="c-city"><label>City</label><select id="co-city"><option value="">Select city</option>${PK_CITIES.map(x => `<option>${x}</option>`).join('')}</select><div class="err">Select your city.</div></div>
        </div>
        <div class="co-grid2">
          <div class="field" id="c-post"><label>Postal code</label><input id="co-post" placeholder="e.g. 46000"/><div class="err">Enter a valid 5-digit postal code.</div></div>
          <div class="field"><label>Landmark <span style="font-weight:400;color:var(--muted)">(optional)</span></label><input id="co-land" placeholder="Nearby landmark"/></div>
        </div>
        <div class="field" style="margin:0"><label style="font-weight:400;font-size:13px;display:flex;gap:8px"><input type="checkbox" id="co-samebill" checked style="width:auto"> Billing address same as shipping</label></div>
      </div>

      <div class="co-card">
        <h2><span class="step">3</span> Delivery option</h2>
        <div class="opt-list">
          <label class="opt sel" id="dl-bykea">
            <input type="radio" name="delivery" value="bykea" checked>
            <span><span class="ot">Bykea</span><span class="od">Delivered by Bykea in ${DELIVERY.bykea.eta}, across Pakistan.</span></span>
            <span class="ofee">$${money(DELIVERY.bykea.fee)}</span>
          </label>
        </div>
      </div>

      <div class="co-card">
        <h2><span class="step">4</span> Payment method</h2>
        <div class="opt-list">
          <label class="opt sel" id="pm-cod" onclick="selectPay('cod')">
            <input type="radio" name="paymethod" value="cod" checked>
            <span><span class="ot">Cash on Delivery</span><span class="od">Pay in cash to the rider when your order arrives.</span></span>
          </label>
          <label class="opt disabled" id="pm-costoe">
            <input type="radio" name="paymethod" value="costoe" disabled>
            <span><span class="ot">Costoe Pays <span class="soon">Coming soon</span></span><span class="od">Online payment through Costoe Pays will be available soon.</span></span>
          </label>
        </div>
        <p class="form-note">For now you can pay with Cash on Delivery. Costoe Pays is coming soon.</p>
      </div>

      <button class="btn-primary" id="place-btn" type="submit" style="max-width:340px">Place order, $${money(total)}</button>
    </form>

    <div class="co-summary">
      <h2>Order summary</h2>
      <div class="sum-line"><span>Items (${cartCount()})</span><span>$${money(sub)}</span></div>
      <div class="sum-line"><span>Delivery (<span id="sum-dlabel">Bykea</span>)</span><span id="sum-ship">$${money(ship)}</span></div>
      <div class="sum-line"><span>Tax (5%)</span><span>$${money(tax)}</span></div>
      <div class="sum-line promo-line" id="sum-promo-line" style="${disc > 0 ? '' : 'display:none'};color:var(--accent);font-weight:700"><span>Sign-up discount (10%, max Rs ${PROMO_MAX_PKR})</span><span id="sum-promo">-$${money(disc)}</span></div>
      <div class="sum-total"><span>Total</span><span id="sum-total">$${money(total)}</span></div>
      <div class="sum-line" style="justify-content:flex-end;color:var(--muted)"><span id="sum-pkr">${pkr(total)}</span></div>
      ${promoUsesLeft() > 0 ? `<div class="promo-note">You have <b>${promoUsesLeft()}</b> sign-up discount(s) left. 10% off, up to Rs ${PROMO_MAX_PKR}, applied automatically.</div>` : ''}
      <div style="margin-top:14px;font-size:13px">${items.map(i => `<div class="sum-line"><span>${i.title.slice(0,24)} x${i.qty}</span><span>$${money(i.price*i.qty)}</span></div>`).join('')}</div>
    </div>
  </div>`;
}

function currentDelivery(){
  const el = document.querySelector('input[name="delivery"]:checked');
  return DELIVERY[el ? el.value : 'bykea'] || DELIVERY.bykea;
}
function recomputeTotals(){
  const sub = cartTotal();
  const d = currentDelivery();
  const tax = +(sub * 0.05).toFixed(2);
  const disc = promoDiscount(sub);
  const total = +(sub + d.fee + tax - disc).toFixed(2);
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  set('sum-ship', '$' + money(d.fee));
  set('sum-dlabel', d.label);
  set('sum-promo', '-$' + money(disc));
  const pl = document.getElementById('sum-promo-line'); if (pl) pl.style.display = disc > 0 ? '' : 'none';
  set('sum-total', '$' + money(total));
  set('sum-pkr', pkr(total));
  const btn = document.getElementById('place-btn');
  if (btn) btn.textContent = `Place order, $${money(total)}`;
}
function selectDelivery(key){
  const r = document.querySelector(`input[name="delivery"][value="${key}"]`);
  if (r) r.checked = true;
  recomputeTotals();
}
function selectPay(method){
  document.getElementById('pm-cod').classList.toggle('sel', method === 'cod');
  document.getElementById('pm-costoe').classList.toggle('sel', method === 'costoe');
  const r = document.querySelector(`input[name="paymethod"][value="${method}"]`);
  if (r) r.checked = true;
}

function fillSavedAddress(){
  const id = $('#co-saved') ? $('#co-saved').value : '';
  if (!id) return;
  const a = store.addresses().find(x => x.id === id);
  if (!a) return;
  const set = (id, val) => { const el = $('#' + id); if (el) el.value = val || ''; };
  set('co-name', a.name);
  set('co-a1', a.a1); set('co-a2', a.a2);
  set('co-city', a.city); set('co-state', a.state);
  set('co-post', a.post); set('co-land', a.land);
  const ph = $('#co-phone'); if (ph) ph.value = (a.phone || '').replace(/\D/g, '').replace(/^92/, '');
}
function placeOrder(e){
  e.preventDefault();
  let ok = true;
  const set = (id, bad) => { const el = $('#' + id); if (el){ el.classList.toggle('invalid', bad); if (bad) ok = false; } };
  const v = id => ($('#' + id) ? $('#' + id).value.trim() : '');
  set('c-name', !v('co-name'));
  set('c-email', !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v('co-email')));
  const phone = v('co-phone').replace(/\D/g, '').replace(/^0/, '');
  set('c-phone', !/^3\d{9}$/.test(phone));
  set('c-a1', !v('co-a1'));
  set('c-state', !v('co-state'));
  set('c-city', !v('co-city'));
  set('c-post', !/^\d{5}$/.test(v('co-post')));
  if (!ok){ toast('Please fix the highlighted fields.'); const bad = document.querySelector('.invalid'); if (bad) bad.scrollIntoView({ behavior: 'smooth', block: 'center' }); return false; }

  const payMethod = 'Cash on Delivery';
  const dlEl = document.querySelector('input[name="delivery"]:checked');
  const delivery = DELIVERY[dlEl ? dlEl.value : 'bykea'] || DELIVERY.bykea;

  const items = cartItems();
  const sub = cartTotal();
  const shipping = delivery.fee;
  const tax = +(sub * 0.05).toFixed(2);
  const discount = promoDiscount(sub);
  const total = +(sub + shipping + tax - discount).toFixed(2);
  const now = new Date();
  const order = {
    id: Math.floor(100000000 + Math.random() * 899999999),
    ts: now.getTime(),
    date: now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
    time: now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    email: v('co-email'), subtotal: sub, tax, shipping, discount, total, payMethod,
    delivery: delivery.label, deliveryEta: delivery.eta,
    items: items.map(i => ({ title: i.title, qty: i.qty, price: i.price })),
    ship: { name: v('co-name'), a1: v('co-a1'), a2: v('co-a2'), city: v('co-city'), state: v('co-state'), post: v('co-post'), land: v('co-land'), phone: '+92' + phone }
  };
  const orders = store.orders(); orders.push(order); store.setOrders(orders);

  // Record sign-up discount usage
  if (discount > 0){
    const su0 = store.session();
    if (su0){ const pu = store.promoUsage(); pu[su0.email] = (pu[su0.email] || 0) + 1; store.setPromoUsage(pu); }
  }

  // Send an order notification to the admin inbox
  const inbox = store.inbox();
  inbox.push({
    mid: 'm' + Date.now(),
    read: false,
    date: order.date, time: order.time,
    from: order.ship.name,
    fromEmail: order.email,
    subject: `New order #${order.id} (${payMethod})`,
    order
  });
  store.setInbox(inbox);

  // Route each seller's items to that seller's own mailbox with full customer details
  const bySeller = {};
  items.forEach(it => {
    if (!it.sellerId) return;
    (bySeller[it.sellerId] = bySeller[it.sellerId] || { sellerName: it.sellerName, items: [] })
      .items.push({ title: it.title, qty: it.qty, price: it.price });
  });
  const sellerIds = Object.keys(bySeller);
  if (sellerIds.length){
    const sinbox = store.sellerInbox();
    sellerIds.forEach((sid, k) => {
      const grp = bySeller[sid];
      const sellerSubtotal = +grp.items.reduce((a, i) => a + i.price * i.qty, 0).toFixed(2);
      const count = grp.items.reduce((a, i) => a + i.qty, 0);
      sinbox.push({
        mid: 'sm' + Date.now() + '-' + k,
        sellerId: sid,
        read: false,
        ts: order.ts,
        date: order.date, time: order.time,
        orderId: order.id,
        subject: `New order #${order.id} - ${count} item(s)`,
        payMethod, delivery: order.delivery, deliveryEta: order.deliveryEta,
        customer: { name: order.ship.name, email: order.email, phone: order.ship.phone },
        ship: { ...order.ship },
        items: grp.items,
        sellerSubtotal,
        orderTotal: order.total
      });
    });
    store.setSellerInbox(sinbox);
  }

  // Reduce stock for seller products that track inventory
  const spAll = store.sellerProducts();
  let changed = false;
  items.forEach(it => {
    if (!it.sellerId) return;
    const sp = spAll.find(p => p.id === it.id);
    if (sp && typeof sp.stock === 'number'){ sp.stock = Math.max(0, sp.stock - it.qty); changed = true; }
  });
  if (changed) store.setSellerProducts(spAll);

  // Remember this address for next time (if not already saved)
  const su = store.session();
  if (su){
    const list = store.addresses();
    const exists = list.some(a => a.email === su.email && a.a1 === order.ship.a1 && a.post === order.ship.post && a.city === order.ship.city);
    if (!exists){
      list.push({ id: 'a' + Date.now(), email: su.email, name: order.ship.name, phone: order.ship.phone, a1: order.ship.a1, a2: order.ship.a2, city: order.ship.city, state: order.ship.state, post: order.ship.post, land: order.ship.land });
      store.setAddresses(list);
    }
  }

  store.setCart([]);
  window._lastOrder = order;
  toast(`Order placed. Paying by ${payMethod}.`);
  go('#/confirmed');
  return false;
}

function viewConfirmed(){
  const o = window._lastOrder;
  if (!o) return emptyState({ title: 'No recent order', text: 'You have no recent order to show.', actions: [{ label: 'Go home', onclick: "go('#/')" }] });
  return `
  <div class="confirm">
    <div class="confirm-card">
      <h1>Order placed</h1>
      <p style="font-size:15px;color:var(--muted)">Thanks, ${o.ship.name.split(' ')[0]}. We have your order and sent a copy to ${o.email}.</p>
      <div class="order-box">
        <b>Order #${o.id}</b><br>${o.date} at ${o.time}<br><br>
        <b>Deliver to:</b> ${o.ship.name}, ${o.ship.a1}${o.ship.a2 ? ', ' + o.ship.a2 : ''}, ${o.ship.city}, ${o.ship.state}, ${o.ship.post}, Pakistan<br>
        <b>Phone:</b> ${o.ship.phone}<br>
        <b>Delivery:</b> ${o.delivery} (${o.deliveryEta})<br>
        <b>Payment:</b> ${o.payMethod}<br><br>
        <b>Items</b><br>${o.items.map(i => `${i.title} x${i.qty}, $${money(i.price * i.qty)}`).join('<br>')}<br><br>
        Subtotal: $${money(o.subtotal)}<br>
        Delivery: $${money(o.shipping)}<br>
        Tax: $${money(o.tax)}<br>
        ${o.discount > 0 ? `Sign-up discount: -$${money(o.discount)}<br>` : ''}
        <b>Total: $${money(o.total)} (${pkr(o.total)})</b>
      </div>
      <div class="row" style="display:flex;gap:12px;justify-content:center;margin-top:20px;flex-wrap:wrap">
        <button class="btn-primary" style="width:auto;padding:12px 26px" onclick="go('#/orders')">View your orders</button>
        <button class="btn-ghost" style="width:auto;padding:12px 26px" onclick="go('#/')">Keep shopping</button>
      </div>
    </div>
  </div>`;
}

/* ---------- admin inbox (mail client) ---------- */
function viewInbox(params){
  if (!isAdmin()){
    window._afterAuth = '#/inbox';
    return `<div class="app-wrap" style="padding:0 16px">${emptyState({
      title: 'Admin sign in required',
      text: 'The order inbox is only available to the Costoe admin account. Please sign in with the admin username and password.',
      actions: [{ label: 'Go to sign in', onclick: "go('#/signin')" }]
    })}</div>`;
  }
  let msgs = store.inbox().slice().reverse();
  const selId = params.get('m');

  const side = `
    <div class="mail-side">
      <div class="who">Signed in as <b>${(store.session()||{}).name || 'Costoe Admin'}</b><br>${SUPPORT_MAIL}</div>
      <div class="mail-nav"><a class="on">Inbox${unreadCount() ? ` <span class="n">${unreadCount()}</span>` : ''}</a></div>
      <div class="signout" onclick="signOut()">Sign out</div>
    </div>`;

  if (!msgs.length){
    return `<div class="mail">${side}<div class="mail-main"><div class="mail-head">Inbox</div>
      <div class="mempty">Nothing here yet. Customer orders and messages from sellers to help@costoe.mails will arrive in this inbox.</div></div></div>`;
  }

  if (selId){
    const raw = store.inbox();
    const m = raw.find(x => x.mid === selId);
    if (m && !m.read){ m.read = true; store.setInbox(raw); msgs = store.inbox().slice().reverse(); renderHeader(); }
    if (!m) return `<div class="mail">${side}<div class="mail-main"><div class="mail-head">Inbox</div><div class="mempty">Message not found. <a onclick="go('#/inbox')">Back to inbox</a></div></div></div>`;
    if (m.kind === 'mail'){
      return `<div class="mail">${side}
        <div class="mail-main">
          <div class="mback" onclick="go('#/inbox')">Back to inbox</div>
          <div class="mview">
            <div class="mv-subj">${m.subject || '(no subject)'}</div>
            <div class="mv-meta">From <b>${m.from}</b> &lt;${m.fromMail || m.fromEmail || ''}&gt; · ${m.date} at ${m.time}</div>
            <div class="mv-block"><div class="mv-body">${(m.body || '').replace(/</g,'&lt;').replace(/\n/g,'<br>')}</div></div>
            <div class="mv-block">
              <h4>Reply</h4>
              <textarea id="rp-body" class="mail-ta" rows="5" placeholder="Write your reply to ${m.from}..."></textarea>
              <div class="row" style="margin-top:10px"><button class="btn-primary" style="width:auto;padding:10px 22px" onclick="adminReply('${m.mid}')">Send reply</button></div>
            </div>
          </div>
        </div></div>`;
    }
    const o = m.order;
    return `<div class="mail">${side}
      <div class="mail-main">
        <div class="mback" onclick="go('#/inbox')">Back to inbox</div>
        <div class="mview">
          <div class="mv-subj">${m.subject}</div>
          <div class="mv-meta">From <b>${m.from}</b> &lt;${m.fromEmail}&gt; · ${m.date} at ${m.time}</div>

          <div class="mv-block"><h4>Customer</h4><div class="mv-kv">
            <div><span class="k">Name</span> ${o.ship.name}</div>
            <div><span class="k">Email</span> ${m.fromEmail}</div>
            <div><span class="k">Phone</span> ${o.ship.phone}</div>
          </div></div>

          <div class="mv-block"><h4>Deliver to</h4><div class="mv-kv">
            <div><span class="k">Address 1</span> ${o.ship.a1}</div>
            ${o.ship.a2 ? `<div><span class="k">Address 2</span> ${o.ship.a2}</div>` : ''}
            <div><span class="k">City</span> ${o.ship.city}</div>
            <div><span class="k">Province</span> ${o.ship.state}</div>
            <div><span class="k">Postal code</span> ${o.ship.post}</div>
            ${o.ship.land ? `<div><span class="k">Landmark</span> ${o.ship.land}</div>` : ''}
            <div><span class="k">Country</span> Pakistan</div>
          </div></div>

          <div class="mv-block"><h4>Delivery and payment</h4><div class="mv-kv">
            <div><span class="k">Delivery</span> ${o.delivery} (${o.deliveryEta})</div>
            <div><span class="k">Payment</span> ${o.payMethod}</div>
            <div><span class="k">Order id</span> #${o.id}</div>
          </div></div>

          <div class="mv-block"><h4>Items</h4>
            <table class="mv-table">
              <thead><tr><th>Product</th><th class="num">Qty</th><th class="num">Unit</th><th class="num">Total</th></tr></thead>
              <tbody>${o.items.map(i => `<tr><td>${i.title}</td><td class="num">${i.qty}</td><td class="num">$${money(i.price)}</td><td class="num">$${money(i.price * i.qty)}</td></tr>`).join('')}</tbody>
            </table>
          </div>

          <div class="mv-kv" style="text-align:right">
            <div>Subtotal: $${money(o.subtotal)}</div>
            <div>Delivery: $${money(o.shipping)}</div>
            <div>Tax: $${money(o.tax)}</div>
            ${o.discount > 0 ? `<div>Sign-up discount: -$${money(o.discount)}</div>` : ''}
          </div>
          <div class="mv-total"><span>Order total</span><span>$${money(o.total)} <span style="color:var(--muted);font-weight:400">(${pkr(o.total)})</span></span></div>
        </div>
      </div></div>`;
  }

  const rows = msgs.map(m => `
    <div class="mrow ${m.read ? 'read' : 'unread'}" onclick="go('#/inbox?m=${m.mid}')">
      <div class="from">${m.read ? '' : '<span class="dot"></span>'}${m.from}</div>
      <div class="subj">${m.subject} <span>· ${m.kind === 'mail' ? 'mail' : m.order.items.reduce((a,i)=>a+i.qty,0) + ' item(s), $' + money(m.order.total)}</span></div>
      <div class="when">${m.date}</div>
    </div>`).join('');
  return `<div class="mail">${side}
    <div class="mail-main"><div class="mail-head">Inbox</div><div class="mlist">${rows}</div></div></div>`;
}

/* ---------- simple info pages ---------- */
function viewInfo(kind){
  if (kind === 'contact'){
    return `<div class="section" style="max-width:760px"><div class="section-head"><h2>Contact us</h2></div>
      <div class="co-card" style="margin:0">
        <p style="font-size:15px">We are here to help with orders, delivery and selling on Costoe.</p>
        <div class="mv-kv" style="margin-top:8px">
          <div><span class="k">Email</span> help@costoe.mails</div>
          <div><span class="k">Support</span> Every day, 9am to 9pm</div>
          <div><span class="k">Delivery</span> Bykea, across Pakistan</div>
          <div><span class="k">Payment</span> Cash on Delivery (Costoe Pays coming soon)</div>
        </div>
        <div class="row" style="margin-top:16px"><button class="btn-primary" style="width:auto;padding:12px 24px" onclick="go('#/products')">Start shopping</button></div>
      </div>

      <div class="co-card" style="margin:16px 0 0">
        <h3 style="margin:0 0 6px">How to complain</h3>
        <p style="font-size:14px;color:var(--muted);margin:0 0 12px">Have an issue with an order, a seller, a payment or a sale? Follow these steps and we will resolve it quickly.</p>
        <div class="flow">
          <div class="flow-step"><span class="n">1</span><div><b>Email our Admin</b><p>Send your complaint to <b>contact.abdullahhassan@gmail.com</b> — our Admin and Issue or Sales Manager at Costoe.</p></div></div>
          <div class="flow-step"><span class="n">2</span><div><b>Add your details</b><p>Include your order id, name, phone and a short description of the issue so it can be checked fast.</p></div></div>
          <div class="flow-step"><span class="n">3</span><div><b>Get a response</b><p>The Issue / Sales Manager reviews every complaint and replies with the next steps or a resolution.</p></div></div>
        </div>
        <div class="mv-kv" style="margin-top:8px">
          <div><span class="k">Complaints</span> contact.abdullahhassan@gmail.com</div>
          <div><span class="k">Handled by</span> Admin · Issue / Sales Manager, Costoe</div>
        </div>
      </div></div>`;
  }
  return `<div class="section" style="max-width:760px"><div class="section-head"><h2>About Costoe</h2></div>
    <div class="co-card" style="margin:0">
      <p style="font-size:15px;line-height:1.6">Costoe is an online store in Pakistan. We bring together electronics, books, gadgets, car and bike accessories, and everyday products in one place, with cash on delivery and Bykea shipping.</p>
      <p style="font-size:15px;line-height:1.6">Anyone can sell on Costoe. Open a seller account, get your own Costoe mailbox, list your products and receive orders with full customer details so you can pack and deliver with confidence.</p>
      <div class="row" style="margin-top:8px"><button class="btn-primary" style="width:auto;padding:12px 24px" onclick="go('#/sell')">Sell on Costoe</button></div>
    </div></div>`;
}

/* ================= router ================= */
function go(hash){ if (location.hash === hash) renderRoute(); else location.hash = hash; }
function parseRoute(){
  const raw = location.hash.replace(/^#/, '') || '/';
  const [path, query] = raw.split('?');
  return { path, params: new URLSearchParams(query || '') };
}
function renderRoute(){
  refreshProducts();
  const { path, params } = parseRoute();
  const parts = path.split('/').filter(Boolean);
  const root = parts[0] || '';
  let html = '';
  switch (root) {
    case '': html = viewHome(); break;
    case 'products': html = viewProducts(params); break;
    case 'search': html = viewSearch(params); break;
    case 'product': html = viewProduct(parts[1]); break;
    case 'cart': html = viewCart(); break;
    case 'signin': html = viewSignin(); break;
    case 'signup': html = viewSignup(); break;
    case 'account': html = viewAccount(); break;
    case 'profile': html = viewProfile(); break;
    case 'wishlist': html = viewWishlist(); break;
    case 'addresses': html = viewAddresses(); break;
    case 'orders': html = viewOrders(); break;
    case 'checkout': html = viewCheckout(); break;
    case 'confirmed': html = viewConfirmed(); break;
    case 'inbox': html = viewInbox(params); break;
    case 'sell': html = viewSellerSignup(); break;
    case 'seller': html = viewSeller(params); break;
    case 'about': html = viewInfo('about'); break;
    case 'contact': html = viewInfo('contact'); break;
    default: html = emptyState({ title: 'Page not found', text: 'That page does not exist.', actions: [{ label: 'Go home', onclick: "go('#/')" }] });
  }
  $('#app').innerHTML = `<div style="min-height:60vh">${html}</div>${footerHTML()}`;
  window.scrollTo(0, 0);
  renderHeader();
}
window.addEventListener('hashchange', renderRoute);
window.addEventListener('DOMContentLoaded', () => { renderHeader(); renderRoute(); fetchRate(); });
