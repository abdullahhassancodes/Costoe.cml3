/* ================= Costoe — seller module ================= */
const SELLER_TYPES = ['Auto Care', 'Electronics', 'Gadgets & Accessories', 'Gaming', 'Books & Stationaries', 'Other (type your own)'];
const splitCSV = s => (s || '').split(',').map(x => x.trim()).filter(Boolean);
const val = sel => { const el = document.querySelector(sel); return el ? el.value.trim() : ''; };
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- become a seller ---------- */
function viewSellerSignup(){
  const user = store.session();
  if (!user || user.role === 'admin'){
    window._afterAuth = '#/sell';
    return `<div class="app-wrap" style="padding:0 16px">${emptyState({
      title: 'Sign in to become a seller',
      text: 'A seller account is linked to your Costoe account, so please sign in or create an account first. Then you can open your store.',
      actions: [{ label: 'Sign in', onclick: "go('#/signin')" }, { label: 'Create account', onclick: "go('#/signup')" }]
    })}</div>`;
  }
  if (currentSeller()){
    return `<div class="app-wrap" style="padding:0 16px">${emptyState({
      title: 'You already have a seller account',
      text: 'Open your dashboard to manage products, discounts and your order mailbox.',
      actions: [{ label: 'Open dashboard', onclick: "go('#/seller')" }]
    })}</div>`;
  }
  return `
  <div class="seller-form">
    <div class="auth-logo" style="text-align:center;margin-bottom:14px"><img class="logo-img" src="assets/costoe-logo.png" alt="costoe"/></div>
    <div class="co-card">
      <h2 style="font-size:22px">Create a seller account</h2>
      <p style="color:var(--muted);font-size:14px;margin-top:-6px">This store will be linked to your account (${esc(user.email)}). Fill in the form and submit to get verified.</p>
      <form onsubmit="return submitSeller(event)">
        <div class="field" id="sf-name"><label>Your name</label><input id="sf-name-i" value="${esc(user.name || '')}" placeholder="First and last name"/><div class="err">Enter your name.</div></div>
        <div class="field" id="sf-email"><label>Contact email</label><input id="sf-email-i" type="email" value="${esc(user.email || '')}" placeholder="you@example.com"/><div class="err">Enter a valid email.</div></div>
        <div class="field" id="sf-store"><label>Seller name (shown to customers)</label><input id="sf-store-i" placeholder="e.g. Ravi Electronics"/><div class="err">Enter the seller name shown on your store.</div></div>

        <div class="field" id="sf-handle"><label>Your Costoe mailbox</label>
          <div class="handle-row"><input id="sf-handle-i" placeholder="yourname" oninput="handlePreview()"/><span class="handle-suffix">@costoe.mails</span></div>
          <div class="hint" id="handle-hint">Costoe gives every seller a mailbox. Customer orders arrive here.</div>
          <div class="err">Choose a mailbox name (letters, numbers and dots).</div>
        </div>

        <div class="field" id="sf-desc"><label>Store description (shown on your store)</label><textarea id="sf-desc-i" rows="3" placeholder="A short line about what you sell"></textarea><div class="err">Add a short description.</div></div>
        <div class="field" id="sf-type"><label>Type of products</label>
          <select id="sf-type-i" onchange="sellerTypeToggle()">
            <option value="">Select a type</option>
            ${SELLER_TYPES.map(t => `<option>${t}</option>`).join('')}
          </select>
          <div class="err">Choose or type a product type.</div>
        </div>
        <div class="field" id="sf-typeother" style="display:none"><label>Type your own</label><input id="sf-typeother-i" placeholder="Type your product type"/></div>
        <button class="btn-primary" type="submit" style="max-width:280px">Submit</button>
      </form>
    </div>
  </div>`;
}
function cleanHandle(v){ return (v || '').toLowerCase().replace(/[^a-z0-9.]/g, ''); }
function handlePreview(){
  const el = document.getElementById('sf-handle-i');
  if (!el) return;
  const h = cleanHandle(el.value);
  if (el.value !== h) el.value = h;
  const hint = document.getElementById('handle-hint');
  if (hint) hint.textContent = h ? `Your mailbox will be ${h}@costoe.mails` : 'Costoe gives every seller a mailbox. Customer orders arrive here.';
}
function sellerTypeToggle(){
  const v = val('#sf-type-i');
  document.getElementById('sf-typeother').style.display = v.startsWith('Other') ? 'block' : 'none';
}
function submitSeller(e){
  e.preventDefault();
  const user = store.session();
  if (!user){ go('#/signin'); return false; }
  let ok = true;
  const set = (id, bad) => { const el = document.getElementById(id); if (el){ el.classList.toggle('invalid', bad); if (bad) ok = false; } };
  const name = val('#sf-name-i'), email = val('#sf-email-i'), storeN = val('#sf-store-i'), desc = val('#sf-desc-i');
  const handle = cleanHandle(val('#sf-handle-i'));
  let type = val('#sf-type-i');
  set('sf-name', !name);
  set('sf-email', !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email));
  set('sf-store', !storeN);
  set('sf-handle', !handle);
  set('sf-desc', !desc);
  if (type.startsWith('Other')) type = val('#sf-typeother-i');
  set('sf-type', !type);
  const mail = handle + '@costoe.mails';
  if (handle && store.sellers().some(s => s.mail === mail)){
    set('sf-handle', true);
    document.getElementById('handle-hint').textContent = 'That mailbox name is taken. Try another.';
    document.getElementById('handle-hint').style.color = 'var(--danger)';
    ok = false;
  }
  if (!ok) return false;

  runVerify(() => {
    const sellers = store.sellers();
    const seller = { id: 's' + Date.now(), userEmail: user.email, name, email, sellerName: storeN, description: desc, type, mail, verified: true, createdAt: Date.now() };
    sellers.push(seller); store.setSellers(sellers);
    toast('Seller account verified.');
    go('#/seller');
  });
  return false;
}

/* ---------- verifying animation (visible) ---------- */
function runVerify(done){
  const ov = document.createElement('div');
  ov.className = 'verify-ov';
  ov.innerHTML = `
    <div class="verify-card">
      <div class="verify-spin" id="v-spin"></div>
      <div class="verify-check" id="v-check"><span></span></div>
      <div class="verify-text" id="v-text">Verifying your details</div>
      <div class="verify-steps" id="v-steps">
        <div class="vstep" data-i="0"></div><div class="vstep" data-i="1"></div><div class="vstep" data-i="2"></div>
      </div>
    </div>`;
  document.body.appendChild(ov);
  const steps = ['Verifying your details', 'Setting up your mailbox', 'Setting up your store'];
  let i = 0;
  const dots = ov.querySelectorAll('.vstep');
  dots[0].classList.add('on');
  const iv = setInterval(() => {
    i++;
    if (i < steps.length){
      document.getElementById('v-text').textContent = steps[i];
      dots[i].classList.add('on');
    } else {
      clearInterval(iv);
      document.getElementById('v-spin').style.display = 'none';
      document.getElementById('v-check').classList.add('show');
      document.getElementById('v-text').textContent = 'Verified';
      document.getElementById('v-text').classList.add('ok');
      setTimeout(() => { ov.remove(); done(); }, 1100);
    }
  }, 850);
}

/* ---------- seller dashboard ---------- */
function viewSeller(params){
  const s = currentSeller();
  if (!s){
    const user = store.session();
    if (!user || user.role === 'admin'){
      window._afterAuth = '#/seller';
      return `<div class="app-wrap" style="padding:0 16px">${emptyState({
        title: 'Seller area',
        text: 'Sign in to your Costoe account, then open a seller account to list products.',
        actions: [{ label: 'Sign in', onclick: "go('#/signin')" }]
      })}</div>`;
    }
    return `<div class="app-wrap" style="padding:0 16px">${emptyState({
      title: 'You do not have a seller account yet',
      text: 'Open your own seller account to list products and receive orders.',
      actions: [{ label: 'Become a seller', onclick: "go('#/sell')" }]
    })}</div>`;
  }
  const tab = params.get('tab') || 'products';
  const mine = store.sellerProducts().filter(p => p.sellerId === s.id);
  const unread = sellerUnread(s.id);
  const tabLink = (id, label, badge) => `<a class="dash-tab ${tab === id ? 'on' : ''}" onclick="go('#/seller?tab=${id}')">${label}${badge ? ` <span class="dt-badge">${badge}</span>` : ''}</a>`;
  let body = '';
  if (tab === 'products') body = dashProducts(mine);
  else if (tab === 'add') body = dashAdd();
  else if (tab === 'discounts') body = dashDiscounts(mine);
  else if (tab === 'mails') body = dashMails(s, params);
  else if (tab === 'learn') body = dashLearn();

  return `
  <div class="dash">
    <div class="dash-head">
      <div>
        <div class="dash-hello">Seller dashboard</div>
        <div class="dash-store">${esc(s.sellerName)}</div>
        <div class="dash-mail">${esc(s.mail)}</div>
      </div>
      <div class="dash-actions">
        <button class="btn-ghost" style="width:auto;padding:9px 16px" onclick="switchToBuyer()">Switch to buyer</button>
        <button class="btn-ghost" style="width:auto;padding:9px 16px" onclick="sellerLogout()">Log out</button>
      </div>
    </div>
    <div class="dash-tabs">
      ${tabLink('products', 'My products')}
      ${tabLink('add', 'Add product')}
      ${tabLink('discounts', 'Discounts')}
      ${tabLink('mails', 'Inbox', unread)}
      ${tabLink('learn', 'Learn more')}
    </div>
    <div class="dash-body">${body}</div>
  </div>`;
}

function dashProducts(mine){
  if (!mine.length){
    return `<div class="empty-state" style="border-radius:16px"><h2>No products yet</h2><p>Add your first product and it goes live on Costoe right away.</p>
      <div class="row"><button class="btn-primary" style="width:auto;padding:12px 24px" onclick="go('#/seller?tab=add')">Add a product</button></div></div>`;
  }
  return `
    <div class="dash-bar"><span>${mine.length} product(s) live</span><button class="btn-primary" style="width:auto;padding:10px 20px" onclick="go('#/seller?tab=add')">Add product</button></div>
    <div class="grid">
      ${mine.slice().reverse().map(p => {
        const off = p.listPrice > p.price ? Math.round((1 - p.price / p.listPrice) * 100) : 0;
        return `<div class="card" style="cursor:default">
          <div class="imgbox" onclick="go('#/product/${p.id}')" style="cursor:pointer"><img src="${p.img}" alt=""></div>
          <div class="ttl">${esc(p.title)}</div>
          <div class="price"><span class="cur">$</span><span class="whole">${money(p.price).split('.')[0]}</span><span class="frac">${money(p.price).split('.')[1]}</span>
            ${off ? `<span class="list"><s>$${money(p.listPrice)}</s></span>` : ''}</div>
          <div class="pkr">${pkr(p.price)}</div>
          ${off ? `<div class="deal">${off}% off applied</div>` : ''}
          <div class="stock-line ${typeof p.stock === 'number' && p.stock <= 5 ? 'low' : ''}">${typeof p.stock === 'number' ? (p.stock <= 0 ? 'Out of stock' : `${p.stock.toLocaleString()} in stock`) : 'In stock'}</div>
          <div class="restock-row">
            <input id="rs-${p.id}" type="number" min="0" max="100000" step="1" value="${typeof p.stock === 'number' ? p.stock : ''}" placeholder="Set stock" class="restock-in">
            <button class="btn-ghost" style="padding:7px 10px;font-size:12px" onclick="updateStock('${p.id}')">Update</button>
          </div>
          <div style="margin-top:8px;display:flex;gap:8px">
            <button class="btn-ghost" style="padding:7px 12px;font-size:13px" onclick="go('#/product/${p.id}')">View</button>
            <button class="btn-ghost" style="padding:7px 12px;font-size:13px;color:var(--danger);border-color:#f0caca" onclick="deleteProduct('${p.id}')">Delete</button>
          </div>
        </div>`;
      }).join('')}
    </div>`;
}

/* ---------- add product ---------- */
function dashAdd(){
  window._newImages = [];
  const typeOpts = CATEGORIES.map(c => `<option>${c.name}</option>`).join('') + `<option>Other (type your own)</option>`;
  return `
    <div class="co-card" style="margin:0">
      <h2 style="font-size:20px">Add a product</h2>
      <div class="field"><label>Product photos (add at least 5)</label>
        <input type="file" id="p-imgs" accept="image/*" multiple onchange="handleImages(event)"/>
        <div class="img-grid" id="img-grid"></div>
        <div class="hint" id="img-count">0 photos added</div>
      </div>
      <div class="field" id="pf-title"><label>Title</label><input id="p-title" placeholder="Product title"/><div class="err">Enter a title.</div></div>

      <div class="field" id="pf-desc"><label>Description</label>
        <div class="rt-toolbar">
          <button type="button" onmousedown="rtCmd(event,'bold')" style="font-weight:800">B</button>
          <button type="button" onmousedown="rtCmd(event,'italic')" style="font-style:italic">I</button>
          <span class="rt-hint">Select text, then Bold or Italic for features</span>
        </div>
        <div id="p-desc" class="rt-edit" contenteditable="true" data-ph="Describe your product. Make key features bold or italic."></div>
        <div class="err">Add a description.</div>
      </div>

      <div class="field" id="pf-type"><label>Type of product</label>
        <select id="p-type" onchange="prodTypeToggle()"><option value="">Select type</option>${typeOpts}</select>
        <div class="err">Choose or type a product type.</div>
      </div>
      <div class="field" id="pf-typeother" style="display:none"><label>Type your own</label><input id="p-typeother" placeholder="Type your product type"/></div>

      <div class="field"><label>Variants</label>
        <div class="vg-fixed">
          <input id="var-size" placeholder="Sizes, comma separated (e.g. S, M, L)"/>
          <input id="var-colour" placeholder="Colours, comma separated (e.g. Black, White)"/>
        </div>
        <div id="vg-container"></div>
        <button type="button" class="btn-ghost" style="width:auto;padding:8px 14px;font-size:13px;margin-top:8px" onclick="addVariantRow()">Add another variant</button>
      </div>

      <div class="co-grid2">
        <div class="field" id="pf-price"><label>Price (USD)</label><input id="p-price" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0.00" oninput="updatePkrPreview()"/><div class="err">Enter a valid price.</div></div>
        <div class="field"><label>Price in PKR (auto)</label><input id="price-pkr" value="Rs 0" readonly/><div class="hint">Live rate: 1 USD = Rs ${Math.round(window._pkrRate)}</div></div>
      </div>

      <div class="field" id="pf-stock"><label>Quantity available (stock)</label>
        <input id="p-stock" type="number" min="1" max="100000" step="1" inputmode="numeric" value="1000" placeholder="e.g. 1000"/>
        <div class="hint">How many units you have. You can set any limit up to 100,000. Stock goes down automatically as customers order.</div>
        <div class="err">Enter a stock quantity between 1 and 100,000.</div>
      </div>

      <button class="btn-primary" style="max-width:260px" onclick="saveProduct()">Save and list product</button>
    </div>`;
}
function prodTypeToggle(){ document.getElementById('pf-typeother').style.display = val('#p-type').startsWith('Other') ? 'block' : 'none'; }
function rtCmd(e, cmd){ e.preventDefault(); document.execCommand(cmd, false, null); }
function addVariantRow(){
  const c = document.getElementById('vg-container');
  const row = document.createElement('div');
  row.className = 'vg-row';
  row.innerHTML = `<input class="vg-name" placeholder="Variant name (e.g. Material)"/><input class="vg-opts" placeholder="Options, comma separated"/><button type="button" class="vg-x" onclick="this.parentNode.remove()">Remove</button>`;
  c.appendChild(row);
}
function updatePkrPreview(){
  const v = parseFloat(val('#p-price')) || 0;
  const el = document.getElementById('price-pkr');
  if (el) el.value = pkr(v);
}
function handleImages(e){
  const files = Array.from(e.target.files || []);
  let pending = files.length;
  if (!pending) return;
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = ev => {
      const img = new Image();
      img.onload = () => {
        const max = 820;
        let { width, height } = img;
        if (width > max || height > max){ const r = Math.min(max / width, max / height); width = Math.round(width * r); height = Math.round(height * r); }
        const cv = document.createElement('canvas'); cv.width = width; cv.height = height;
        cv.getContext('2d').drawImage(img, 0, 0, width, height);
        window._newImages.push(cv.toDataURL('image/jpeg', 0.72));
        if (--pending <= 0) renderImgGrid();
        else renderImgGrid();
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  });
  e.target.value = '';
}
function renderImgGrid(){
  const g = document.getElementById('img-grid');
  if (!g) return;
  g.innerHTML = window._newImages.map((src, i) => `<div class="img-cell"><img src="${src}" alt=""><span class="img-x" onclick="removeImage(${i})">×</span></div>`).join('');
  const c = document.getElementById('img-count');
  if (c){ c.textContent = `${window._newImages.length} photo(s) added${window._newImages.length < 5 ? ' — add at least 5' : ''}`; c.style.color = ''; }
}
function removeImage(i){ window._newImages.splice(i, 1); renderImgGrid(); }

function saveProduct(){
  let ok = true;
  const set = (id, bad) => { const el = document.getElementById(id); if (el){ el.classList.toggle('invalid', bad); if (bad) ok = false; } };
  const title = val('#p-title');
  let type = val('#p-type'); if (type.startsWith('Other')) type = val('#p-typeother');
  const price = parseFloat(val('#p-price'));
  const stock = parseInt(val('#p-stock'), 10);
  let descHTML = (document.getElementById('p-desc') || {}).innerHTML || '';
  descHTML = descHTML.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/ on\w+="[^"]*"/gi, '');
  const descText = (document.getElementById('p-desc') || {}).innerText || '';

  set('pf-title', !title);
  set('pf-type', !type);
  set('pf-price', !(price > 0));
  set('pf-stock', !(stock >= 1 && stock <= 100000));
  set('pf-desc', !descText.trim());
  const imgsOk = window._newImages && window._newImages.length >= 5;
  const ic = document.getElementById('img-count');
  if (!imgsOk && ic){ ic.style.color = 'var(--danger)'; ok = false; }
  if (!ok){ toast('Please complete the highlighted fields (5 photos minimum).'); return; }

  const variants = [];
  const sz = val('#var-size'); if (sz) variants.push({ name: 'Size', options: splitCSV(sz) });
  const col = val('#var-colour'); if (col) variants.push({ name: 'Colour', options: splitCSV(col) });
  document.querySelectorAll('#vg-container .vg-row').forEach(r => {
    const n = r.querySelector('.vg-name').value.trim();
    const o = r.querySelector('.vg-opts').value.trim();
    if (n && o) variants.push({ name: n, options: splitCSV(o) });
  });

  const s = currentSeller();
  const product = {
    id: 'sp' + Date.now(),
    sellerId: s.id, sellerName: s.sellerName,
    title, category: type, descHTML,
    images: window._newImages.slice(), img: window._newImages[0],
    variants,
    origPrice: price, price: price, listPrice: price,
    stock: stock,
    discount: null,
    createdAt: Date.now()
  };
  const all = store.sellerProducts(); all.push(product);
  if (store.setSellerProducts(all)){
    toast('Product listed on Costoe.');
    go('#/seller?tab=products');
  }
}
function updateStock(id){
  const el = document.getElementById('rs-' + id);
  if (!el) return;
  let n = parseInt(el.value, 10);
  if (isNaN(n) || n < 0){ toast('Enter a valid stock number.'); return; }
  if (n > 100000) n = 100000;
  const all = store.sellerProducts();
  const p = all.find(x => x.id === id);
  if (p){ p.stock = n; store.setSellerProducts(all); toast(`Stock updated to ${n.toLocaleString()}.`); renderRoute(); }
}
function deleteProduct(id){
  const all = store.sellerProducts().filter(p => p.id !== id);
  store.setSellerProducts(all);
  toast('Product removed.');
  renderRoute();
}

/* ---------- discounts ---------- */
function dashDiscounts(mine){
  if (!mine.length){
    return `<div class="empty-state" style="border-radius:16px"><h2>No products to discount</h2><p>Add a product first, then you can put it on discount.</p>
      <div class="row"><button class="btn-primary" style="width:auto;padding:12px 24px" onclick="go('#/seller?tab=add')">Add a product</button></div></div>`;
  }
  const cats = [...new Set(mine.map(p => p.category))];
  return `
    <div class="co-card" style="margin:0">
      <h2 style="font-size:20px">Set a discount</h2>
      <div class="field"><label>Apply to</label>
        <select id="d-scope" onchange="discountScope()">
          <option value="selected">Selected products</option>
          <option value="cat">A whole catalogue of mine</option>
        </select>
      </div>
      <div class="field" id="d-cat-wrap" style="display:none"><label>Catalogue</label>
        <select id="d-cat">${cats.map(c => `<option>${esc(c)}</option>`).join('')}</select>
      </div>
      <div class="field" id="d-list-wrap"><label>Choose products</label>
        <div class="d-list">
          ${mine.map(p => `<label class="d-item"><input type="checkbox" class="d-pick" value="${p.id}"> <img src="${p.img}" alt=""> <span>${esc(p.title)}</span> <b>$${money(p.origPrice)}</b></label>`).join('')}
        </div>
      </div>
      <div class="co-grid2">
        <div class="field"><label>Discount amount</label><input id="d-value" type="number" min="0" step="0.01" placeholder="e.g. 15"/></div>
        <div class="field"><label>Discount type</label>
          <select id="d-unit"><option value="pct">Percent (%)</option><option value="usd">US Dollars ($)</option><option value="pkr">Rupees (PKR/Rs)</option></select>
        </div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="btn-primary" style="width:auto;padding:12px 24px" onclick="applyDiscount()">Apply discount</button>
        <button class="btn-ghost" style="width:auto;padding:12px 24px" onclick="clearDiscount()">Remove discount from selected</button>
      </div>
      <p class="hint" style="margin-top:10px">The discounted price is shown to customers on the selected products.</p>
    </div>`;
}
function discountScope(){
  const v = val('#d-scope');
  document.getElementById('d-cat-wrap').style.display = v === 'cat' ? 'block' : 'none';
  document.getElementById('d-list-wrap').style.display = v === 'cat' ? 'none' : 'block';
}
function targetProductIds(){
  const scope = val('#d-scope');
  const mine = store.sellerProducts().filter(p => p.sellerId === currentSeller().id);
  if (scope === 'cat'){ const c = val('#d-cat'); return mine.filter(p => p.category === c).map(p => p.id); }
  return Array.from(document.querySelectorAll('.d-pick:checked')).map(c => c.value);
}
function applyDiscount(){
  const ids = targetProductIds();
  if (!ids.length){ toast('Select at least one product.'); return; }
  const value = parseFloat(val('#d-value'));
  const unit = val('#d-unit');
  if (!(value > 0)){ toast('Enter a discount amount.'); return; }
  const all = store.sellerProducts();
  all.forEach(p => {
    if (!ids.includes(p.id)) return;
    const base = p.origPrice || p.price;
    let np = base;
    if (unit === 'pct') np = base * (1 - value / 100);
    else if (unit === 'usd') np = base - value;
    else if (unit === 'pkr') np = base - (value / window._pkrRate);
    np = Math.max(0.01, +np.toFixed(2));
    p.origPrice = base; p.listPrice = base; p.price = np;
    p.discount = { type: unit, value };
  });
  store.setSellerProducts(all);
  toast(`Discount applied to ${ids.length} product(s).`);
  renderRoute();
}
function clearDiscount(){
  const ids = targetProductIds();
  if (!ids.length){ toast('Select at least one product.'); return; }
  const all = store.sellerProducts();
  all.forEach(p => { if (ids.includes(p.id)){ p.price = p.origPrice || p.price; p.listPrice = p.price; p.discount = null; } });
  store.setSellerProducts(all);
  toast('Discount removed.');
  renderRoute();
}

/* ---------- shipping timeline (per order, real time) ---------- */
function shipTimeline(m){
  const DAY = 86400000;
  const start = m.ts || Date.parse(m.date) || Date.now();
  const elapsed = Math.max(0, (Date.now() - start) / DAY);   // days since order
  const SHIP = 5, GRACE = 1, TOTAL = SHIP + GRACE;           // 5-day window + 1-day late limit
  const markPct = (SHIP / TOTAL) * 100;                      // 5-day mark
  const bluePct = (Math.min(elapsed, SHIP) / TOTAL) * 100;
  const redPct  = elapsed > SHIP ? ((Math.min(elapsed, TOTAL) - SHIP) / TOTAL) * 100 : 0;

  let cls, status, sub;
  if (elapsed <= SHIP){
    cls = 'ok';
    const dayNo = Math.min(SHIP, Math.floor(elapsed) + 1);
    const leftD = Math.max(0, SHIP - elapsed);
    const leftH = Math.round(leftD * 24);
    status = `On time · day ${dayNo} of ${SHIP}`;
    sub = leftH >= 24 ? `${Math.floor(leftD)} day(s) left to ship` : `${leftH} hour(s) left to ship`;
  } else if (elapsed <= TOTAL){
    cls = 'late';
    const leftH = Math.round((TOTAL - elapsed) * 24);
    status = `Late · 1-day grace limit`;
    sub = `${leftH} hour(s) before this order is overdue`;
  } else {
    cls = 'over';
    status = `Overdue · shipping limit passed`;
    sub = `Ship immediately — ${Math.floor(elapsed - SHIP)} day(s) past the ${SHIP}-day limit`;
  }

  return `
    <div class="mv-block ship-tl ${cls}">
      <h4>Shipping timeline</h4>
      <div class="ship-status">${status}</div>
      <div class="ship-track">
        <div class="ship-fill blue" style="width:${bluePct.toFixed(2)}%"></div>
        <div class="ship-fill red" style="left:${markPct.toFixed(2)}%;width:${redPct.toFixed(2)}%"></div>
        <div class="ship-mark" style="left:${markPct.toFixed(2)}%"><span>5-day limit</span></div>
      </div>
      <div class="ship-scale"><span>Order placed</span><span>Ship within 5 days</span><span>Late (+1)</span></div>
      <div class="ship-sub">${sub}</div>
    </div>`;
}

/* ---------- seller mailbox (real orders) ---------- */
function dashMails(seller, params){
  let msgs = store.sellerInbox().filter(m => m.sellerId === seller.id).slice().reverse();
  const selId = params.get('m');

  if (selId){
    const raw = store.sellerInbox();
    const m = raw.find(x => x.mid === selId && x.sellerId === seller.id);
    if (m && !m.read){ m.read = true; store.setSellerInbox(raw); renderHeader(); }
    if (!m) return `<div class="mempty">Message not found. <a onclick="go('#/seller?tab=mails')">Back to inbox</a></div>`;
    if (m.kind === 'mail'){
      return `
        <div class="smail-back" onclick="go('#/seller?tab=mails')">Back to inbox</div>
        <div class="smail-view">
          <div class="sv-subj">${esc(m.subject || '(no subject)')}</div>
          <div class="sv-meta">From <b>${esc(m.from || 'Costoe Support')}</b> &lt;${esc(m.fromMail || SUPPORT_MAIL)}&gt; · ${m.date} at ${m.time}</div>
          <div class="mv-block"><div class="mv-body">${esc(m.body || '').replace(/\n/g,'<br>')}</div></div>
          <div class="mv-block">
            <h4>Reply to Costoe Support</h4>
            <textarea id="srp-body" class="mail-ta" rows="5" placeholder="Write your reply..."></textarea>
            <div class="row" style="margin-top:10px"><button class="btn-primary" style="width:auto;padding:10px 22px" onclick="sellerReplyMail('${m.mid}')">Send reply</button></div>
          </div>
        </div>`;
    }
    const count = m.items.reduce((a, i) => a + i.qty, 0);
    return `
      <div class="smail-back" onclick="go('#/seller?tab=mails')">Back to inbox</div>
      <div class="smail-view">
        <div class="sv-subj">${esc(m.subject)}</div>
        <div class="sv-meta">To <b>${esc(seller.mail)}</b> · ${m.date} at ${m.time}</div>

        ${shipTimeline(m)}

        <div class="mv-block"><h4>Customer</h4><div class="mv-kv">
          <div><span class="k">Name</span> ${esc(m.customer.name)}</div>
          <div><span class="k">Email</span> ${esc(m.customer.email)}</div>
          <div><span class="k">Phone</span> ${esc(m.customer.phone)}</div>
        </div></div>

        <div class="mv-block"><h4>Billing / delivery address</h4><div class="mv-kv">
          <div><span class="k">Name</span> ${esc(m.ship.name)}</div>
          <div><span class="k">Address 1</span> ${esc(m.ship.a1)}</div>
          ${m.ship.a2 ? `<div><span class="k">Address 2</span> ${esc(m.ship.a2)}</div>` : ''}
          <div><span class="k">City</span> ${esc(m.ship.city)}</div>
          <div><span class="k">Province</span> ${esc(m.ship.state)}</div>
          <div><span class="k">Postal code</span> ${esc(m.ship.post)}</div>
          ${m.ship.land ? `<div><span class="k">Landmark</span> ${esc(m.ship.land)}</div>` : ''}
          <div><span class="k">Phone</span> ${esc(m.ship.phone)}</div>
          <div><span class="k">Country</span> Pakistan</div>
        </div></div>

        <div class="mv-block"><h4>Delivery and payment</h4><div class="mv-kv">
          <div><span class="k">Delivery</span> ${esc(m.delivery)} (${esc(m.deliveryEta)})</div>
          <div><span class="k">Payment</span> ${esc(m.payMethod)}</div>
          <div><span class="k">Order id</span> #${m.orderId}</div>
        </div></div>

        <div class="mv-block"><h4>Your items (${count})</h4>
          <table class="mv-table">
            <thead><tr><th>Product</th><th class="num">Qty</th><th class="num">Unit</th><th class="num">Total</th></tr></thead>
            <tbody>${m.items.map(i => `<tr><td>${esc(i.title)}</td><td class="num">${i.qty}</td><td class="num">$${money(i.price)}<div class="tpkr">${pkr(i.price)}</div></td><td class="num">$${money(i.price * i.qty)}<div class="tpkr">${pkr(i.price * i.qty)}</div></td></tr>`).join('')}</tbody>
          </table>
        </div>

        <div class="mv-total"><span>Your items subtotal</span><span>$${money(m.sellerSubtotal)} <span style="color:var(--muted);font-weight:400">(${pkr(m.sellerSubtotal)})</span></span></div>
        <div class="sv-note">Full order total paid by customer: $${money(m.orderTotal)} (${pkr(m.orderTotal)}), including delivery and tax.</div>
      </div>`;
  }

  if (params.get('compose')){
    return `
      <div class="smail-back" onclick="go('#/seller?tab=mails')">Back to inbox</div>
      <div class="smail-view">
        <div class="sv-subj">New mail to Costoe Support</div>
        <div class="sv-meta">From <b>${esc(seller.mail)}</b> · To <b>${SUPPORT_MAIL}</b></div>
        <div class="mv-block">
          <label class="fl">Subject</label>
          <input id="sc-subject" class="mail-in" type="text" placeholder="What is this about?">
          <label class="fl" style="margin-top:12px">Message</label>
          <textarea id="sc-body" class="mail-ta" rows="7" placeholder="Write your message to Costoe Support..."></textarea>
          <div class="row" style="margin-top:12px"><button class="btn-primary" style="width:auto;padding:11px 26px" onclick="sendSellerMail()">Send mail</button></div>
        </div>
      </div>`;
  }

  const composeBtn = `<button class="btn-outline btn-compose" onclick="go('#/seller?tab=mails&compose=1')">New mail</button>`;

  if (!msgs.length){
    return `<div class="smail-head"><span>Mailbox</span><span class="sh-addr">${esc(seller.mail)} ${composeBtn}</span></div>
      <div class="empty-state" style="border-radius:16px"><h2>No mail yet</h2><p>Order notifications and messages from Costoe Support arrive here. Use <b>New mail</b> to contact Costoe Support any time.</p></div>`;
  }
  const rows = msgs.map(m => {
    if (m.kind === 'mail'){
      return `
      <div class="smail-card ${m.read ? 'read' : 'unread'}" onclick="go('#/seller?tab=mails&m=${m.mid}')">
        <div class="sc-top">
          <div class="sc-from">${m.read ? '' : '<span class="dot"></span>'}${esc(m.from || 'Costoe Support')}</div>
          <div class="sc-when">${m.date}</div>
        </div>
        <div class="sc-subj">${esc(m.subject || '(no subject)')}</div>
        <div class="sc-line">Message from Costoe Support</div>
      </div>`;
    }
    const count = m.items.reduce((a, i) => a + i.qty, 0);
    return `
    <div class="smail-card ${m.read ? 'read' : 'unread'}" onclick="go('#/seller?tab=mails&m=${m.mid}')">
      <div class="sc-top">
        <div class="sc-from">${m.read ? '' : '<span class="dot"></span>'}${esc(m.customer.name)}</div>
        <div class="sc-when">${m.date}</div>
      </div>
      <div class="sc-subj">${esc(m.subject)}</div>
      <div class="sc-line">${count} item(s) · $${money(m.sellerSubtotal)} · ${pkr(m.sellerSubtotal)}</div>
    </div>`;
  }).join('');
  return `
    <div class="smail-head"><span>Mailbox${sellerUnread(seller.id) ? ` · ${sellerUnread(seller.id)} unread` : ''}</span><span class="sh-addr">${esc(seller.mail)} ${composeBtn}</span></div>
    <div class="smail-list">${rows}</div>`;
}
function sendSellerMail(){
  const seller = currentSeller();
  if (!seller){ toast('Sign in as a seller first.'); return; }
  const subEl = document.getElementById('sc-subject');
  const bodyEl = document.getElementById('sc-body');
  const subject = (subEl ? subEl.value : '').trim();
  const body = (bodyEl ? bodyEl.value : '').trim();
  if (!body){ toast('Write a message first.'); return; }
  const now = new Date();
  const inbox = store.inbox();
  inbox.push({
    mid: 'm' + Date.now(),
    read: false,
    kind: 'mail',
    date: now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
    time: now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    from: seller.sellerName || seller.name || 'Seller',
    fromMail: seller.mail,
    fromSellerId: seller.id,
    to: SUPPORT_MAIL,
    subject: subject || '(no subject)',
    body
  });
  store.setInbox(inbox);
  toast('Mail sent to Costoe Support.');
  go('#/seller?tab=mails');
}
function sellerReplyMail(mid){
  const seller = currentSeller();
  if (!seller){ toast('Sign in as a seller first.'); return; }
  const el = document.getElementById('srp-body');
  const body = (el ? el.value : '').trim();
  if (!body){ toast('Write a reply first.'); return; }
  const orig = store.sellerInbox().find(x => x.mid === mid);
  const now = new Date();
  const inbox = store.inbox();
  inbox.push({
    mid: 'm' + Date.now(),
    read: false,
    kind: 'mail',
    date: now.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
    time: now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    from: seller.sellerName || seller.name || 'Seller',
    fromMail: seller.mail,
    fromSellerId: seller.id,
    to: SUPPORT_MAIL,
    subject: 'Re: ' + ((orig && orig.subject) || '(no subject)'),
    body
  });
  store.setInbox(inbox);
  toast('Reply sent to Costoe Support.');
  go('#/seller?tab=mails');
}

/* ---------- learn more ---------- */
function dashLearn(){
  return `
    <div class="co-card" style="margin:0">
      <h2 style="font-size:20px">How selling on Costoe works</h2>
      <p style="font-size:14px;color:var(--muted)">You get paid for the orders customers place on your listings. Here is the flow from order to payment.</p>
      <div class="flow">
        <div class="flow-step"><span class="n">1</span><div><b>Customer orders</b><p>A customer buys your product and pays by Cash on Delivery or Costoe Pays. The order lands in your mailbox.</p></div></div>
        <div class="flow-step"><span class="n">2</span><div><b>Packaging by seller</b><p>You pack the item securely and get it ready.</p></div></div>
        <div class="flow-step"><span class="n">3</span><div><b>Processing</b><p>The order is marked ready for pickup.</p></div></div>
        <div class="flow-step"><span class="n">4</span><div><b>Delivered</b><p>Your own delivery rider or Bykea delivers it. Bykea is the easiest way to avoid fraud.</p></div></div>
        <div class="flow-step"><span class="n">5</span><div><b>You get paid</b><p>After the customer receives the order, the payment is settled to you.</p></div></div>
      </div>
      <div class="mv-block" style="margin-top:6px">
        <h4>Have a complaint?</h4>
        <p style="font-size:13.5px;color:var(--muted);margin:0">Complain about any issue at <b>contact.abdullahhassan@gmail.com</b> — our Admin and Issue or Sales Manager at Costoe. Include your order id and details for a fast resolution.</p>
      </div>
      <a class="btn-primary" href="assets/costoe-seller-guide.docx" download style="display:inline-block;width:auto;padding:12px 24px;text-align:center;text-decoration:none;margin-top:6px">Download the full guide (DOCX)</a>
    </div>`;
}

/* ---------- session helpers ---------- */
function switchToBuyer(){ toast('Switched to buyer.'); go('#/'); }
function sellerLogout(){ signOut(); }
