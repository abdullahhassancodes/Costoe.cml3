# Costoe

Costoe is an online store (static site: HTML, CSS, JavaScript — no backend).

## Run locally
Just open `index.html` in a browser, or serve the folder:
```
python3 -m http.server 8080
```
Then visit http://localhost:8080

## Structure
- `index.html` — app shell
- `app.js` — storefront (home, catalogues, cart, checkout, admin inbox)
- `seller.js` — seller accounts, dashboard, product listing, discounts, seller mailbox
- `styles.css` — styles
- `data.js` — catalogues / base product data
- `assets/` — logos, banners, product photos, seller guide (DOCX)
- `netlify.toml` — Netlify build + SPA redirect config

## Deploy
Hosted on Netlify. Pushing to the `main` branch auto-publishes the live site.
