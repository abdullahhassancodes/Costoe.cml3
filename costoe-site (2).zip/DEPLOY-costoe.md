# Connecting your domain to Costoe (Netlify + Hostinger)

Your Costoe site is a static site, so hosting is free and fast. There are 3 stages:
**A) Buy a domain (Hostinger) → B) Deploy the site (Netlify) → C) Connect the domain.**

The files to upload are in this folder (or use `costoe-site.zip`).

---

## A) Buy your domain on Hostinger

1. Go to **hostinger.com → Domains → Domain Name Search**.
2. Search the name you want, e.g. `costoe.com` (or `.store`, `.shop`, `.pk`, etc.).
3. Add to cart and complete checkout.
4. After purchase it appears under **hPanel → Domains**.

*(You do NOT need Hostinger web hosting — just the domain. Netlify will host the site.)*

---

## B) Deploy the site to Netlify (free)

### Fastest way — drag & drop
1. Create a free account at **app.netlify.com**.
2. Go to **app.netlify.com/drop**.
3. Drag the **whole Costoe folder** (the one containing `index.html`) onto the page.
   - If you have the zip, unzip it first and drag the unzipped folder.
4. Netlify gives you a live URL instantly, e.g. `https://random-name-123.netlify.app`.
5. (Optional) **Site configuration → Change site name** to make it `costoe.netlify.app`.

Your site is now live on the internet. Next, put your own domain in front of it.

---

## C) Connect your Hostinger domain to Netlify

In Netlify: **Site configuration → Domain management → Add a domain** → type your domain
(e.g. `costoe.com`) → **Verify → Add domain**.

Now choose ONE of the two methods below.

### ✅ Method 1 — Point Hostinger nameservers to Netlify (recommended, simplest)
Netlify manages all DNS for you; you just paste 4 nameservers into Hostinger.

1. In Netlify, when you add the domain, choose **"Set up Netlify DNS"**. It shows **4 nameservers**, like:
   ```
   dns1.p01.nsone.net
   dns2.p01.nsone.net
   dns3.p01.nsone.net
   dns4.p01.nsone.net
   ```
   (Yours may be slightly different — copy the exact ones Netlify shows you.)
2. In **Hostinger hPanel → Domains → (your domain) → DNS / Nameservers → Change Nameservers**.
3. Select **"Use custom nameservers"** and paste Netlify's 4 nameservers (remove Hostinger's).
4. Save. Done.

### 🔧 Method 2 — Keep Hostinger DNS, add records manually
Use this if you want to keep other DNS (email, etc.) on Hostinger.

In **Hostinger hPanel → Domains → (your domain) → DNS Zone**, add:

| Type  | Name / Host | Value / Points to            | TTL   |
|-------|-------------|------------------------------|-------|
| A     | `@`         | `75.2.60.5`                  | 14400 |
| CNAME | `www`       | `YOUR-SITE.netlify.app`      | 14400 |

- Replace `YOUR-SITE` with your Netlify site name.
- Delete any existing conflicting `A @` or `CNAME www` records first.
- In Netlify keep the domain added (it will verify these records).

---

## D) Turn on HTTPS (free)
After DNS propagates (usually 15 min–2 hrs, up to 24 hrs):
- Netlify → **Domain management → HTTPS → Verify DNS / Provision certificate**.
- Netlify auto-issues a free Let's Encrypt SSL certificate. Your site becomes `https://costoe.com`.
- Turn on **"Force HTTPS"**.

---

## Checklist
- [ ] Domain purchased on Hostinger
- [ ] Site deployed to Netlify (`*.netlify.app` works)
- [ ] Domain added in Netlify
- [ ] Nameservers changed (Method 1) OR A/CNAME records added (Method 2)
- [ ] HTTPS certificate provisioned + Force HTTPS on
- [ ] Visit `https://yourdomain` — Costoe loads 🎉

---

## Important note about data
Costoe currently stores accounts, products, orders and the seller mailbox in **each visitor's own browser** (localStorage). That's great for a demo/portfolio, but it means data is NOT shared between people or devices — a buyer's order on their phone will not appear in a seller's inbox on another device.

If you want a **real multi-user store** (shared accounts/products/orders, a real login, order emails that truly reach sellers), that needs a small backend (database + auth). I can build that version next — just say the word.
