/* ================= Costoe — catalog ================= */
/* Products are empty for now. Add product objects to populate the store.
   Shape:
   {
     id:"unique-id", title:"", brand:"", category:"Electronics",
     price:0, listPrice:0, rating:4.5, reviews:0,
     img:"assets/products/your-image.jpg", stock:true,
     bullets:["...","..."]
   }
   The "category" must match one of the COSTOE_CATEGORIES names below.
*/
window.COSTOE_PRODUCTS = [];

/* Catalogues shown on the home page, nav and search filter. */
window.COSTOE_CATEGORIES = [
  { name: "Digitals",               img: "assets/banners/cat-digitals.png" },
  { name: "Electronics",            img: "assets/banners/cat-electronics.png" },
  { name: "Books & Stationaries",   img: "assets/banners/cat-books.png" },
  { name: "Gadgets & Accessories",  img: "assets/banners/cat-gadgets.png" },
  { name: "Car & Bike Accessories", img: "assets/banners/cat-car-bike.png" },
  { name: "Auto Care Products",     img: "assets/banners/cat-auto.png" }
];
