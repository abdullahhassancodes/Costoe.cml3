# Costoe → GitHub → Netlify (auto-updating deploy)

Goal: put the Costoe files on GitHub, connect Netlify to that repo, and then
**every change you push auto-publishes to your live site**.

You only do the SETUP once. After that, updating the site = push to GitHub.

First get the files onto your computer:
- Download this project folder from the workspace (or unzip `costoe-site.zip`)
  into a folder named `costoe` on your computer.

---

# PART 1 — Put the files on GitHub

Pick ONE path.

## Path A — No command line (GitHub website)
Easiest if you don't use `git`.

1. Create a free account at **github.com**.
2. Click **+ (top right) → New repository**.
   - Repository name: `costoe`
   - Visibility: **Public** (or Private — Netlify works with both)
   - Do NOT add a README (you already have one)
   - Click **Create repository**.
3. On the empty repo page, click **"uploading an existing file"**.
4. Drag ALL the Costoe files/folders (`index.html`, `app.js`, `seller.js`,
   `styles.css`, `data.js`, `assets/`, `netlify.toml`, `README.md`, `.gitignore`)
   into the upload box.
5. Scroll down, type a message like `Initial Costoe site`, click **Commit changes**.

Your code is now on GitHub. To UPDATE later (website way):
- Open the file in the repo → pencil ✏️ icon → edit → **Commit changes**, OR
- Repo home → **Add file → Upload files** → drag the changed files → **Commit changes**.

## Path B — Command line (git) — the "industrial" / proper way
Install Git first (git-scm.com). Then in a terminal:

```bash
cd path/to/costoe          # go into your project folder

git init                   # start a repo
git add .                  # stage all files
git commit -m "Initial Costoe site"

git branch -M main         # name the branch 'main'

# create an empty repo named 'costoe' on github.com first, then:
git remote add origin https://github.com/YOUR-USERNAME/costoe.git
git push -u origin main
```

Enter your GitHub username + a **Personal Access Token** as the password when asked
(GitHub → Settings → Developer settings → Personal access tokens → generate one with
`repo` scope). Paste the token as the password.

To UPDATE later (command line):
```bash
git add .
git commit -m "Describe what changed"
git push
```
That's the whole update loop.

---

# PART 2 — Connect Netlify to the repo (auto-deploy)

Do this ONCE.

1. Log in at **app.netlify.com**.
2. **Add new site → Import an existing project**.
3. Choose **GitHub** → authorize Netlify → pick the **costoe** repository.
4. Build settings (for this static site):
   - **Build command:** leave EMPTY
   - **Publish directory:** `.`  (a single dot = the repo root)
   - (The included `netlify.toml` already sets these, so you can just accept defaults.)
5. Click **Deploy**. In ~30–60 seconds you get a live URL like
   `https://your-site.netlify.app`.

Now the magic is on: **every `git push` (or website commit) to `main` makes Netlify
rebuild and publish automatically.** You'll see each deploy under
Netlify → **Deploys**, with build logs and one-click **rollback** to any older version.

---

# PART 3 — The update workflow from here on

1. Edit files (on your computer, or I edit them here and you download them).
2. Get the changes into the repo:
   - Command line: `git add . && git commit -m "..." && git push`
   - Website: upload/edit the changed files and Commit.
3. Netlify auto-detects the push and publishes. Done — refresh your live site.

No re-dragging, no manual upload to Netlify ever again.

---

# Handy extras (optional)
- **Custom domain:** Netlify → Domain management → Add domain (see `DEPLOY-costoe.md`
  for the Hostinger steps).
- **Rollback a bad change:** Netlify → Deploys → pick a previous deploy →
  **Publish deploy**.
- **Preview before going live:** open a Pull Request on GitHub; Netlify builds a
  temporary "Deploy Preview" URL for it.

---

# One important reminder about the files
The current, up-to-date Costoe files live in THIS workspace. Whenever I make future
changes for you here, they will NOT reach your live site by themselves — you must get
those changed files into GitHub (upload or `git push`). Once that push happens, Netlify
publishes them automatically.

Also note: Costoe stores data (accounts, products, orders, seller mailbox) in each
visitor's own browser (localStorage). Updating code does not create shared data across
users/devices. For a real shared multi-user store you'd need a backend — ask me and I'll
build that version.
